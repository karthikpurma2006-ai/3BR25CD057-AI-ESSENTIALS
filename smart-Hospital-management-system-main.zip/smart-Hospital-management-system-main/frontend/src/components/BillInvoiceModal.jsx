import React, { useState } from 'react';
import { X, Printer, Download, CreditCard, CheckCircle2 } from 'lucide-react';
import html2pdf from 'html2pdf.js';
import { api } from '../services/api';
import { useNotification } from '../context/NotificationContext';

export const BillInvoiceModal = ({ bill, onClose, onRefresh }) => {
  const { addToast } = useNotification();
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('UPI');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!bill) return null;

  const downloadPDF = () => {
    const element = document.getElementById('bill-print-area');
    const opt = {
      margin: 0.5,
      filename: `${bill.bill_code}_invoice.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
  };

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    if (!payAmount || parseFloat(payAmount) <= 0) {
      addToast('Please enter a valid payment amount', 'warning');
      return;
    }

    try {
      setIsProcessing(true);
      await api.customAction('bills', bill.id, 'add_payment', {
        amount: parseFloat(payAmount),
        payment_method: payMethod
      });
      addToast(`Payment of ₹${payAmount} recorded successfully!`, 'success');
      setPayAmount('');
      if (onRefresh) onRefresh();
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '750px', background: '#0f172a' }}>
        <div className="modal-header">
          <h3 style={{ fontSize: '1.1rem' }}>Hospital Billing Invoice ({bill.bill_code})</h3>
          <button onClick={onClose} style={{ background: 'none', color: '#94a3b8' }}>
            <X size={20} />
          </button>
        </div>

        <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div id="bill-print-area" style={{ background: '#ffffff', color: '#0f172a', padding: '2rem', borderRadius: '12px' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '2px solid #0891b2', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
              <div>
                <h2 style={{ color: '#0891b2', fontSize: '1.4rem', fontWeight: 800 }}>Sanjeevini Multispeciality Hospital</h2>
                <p style={{ fontSize: '0.8rem', color: '#475569' }}>Tax & Billing Services • Reg No: SANJEEVINI-2026-REG</p>
              </div>
              <div style={{ textAlign: 'right' }}>
                <h4 style={{ color: '#1e293b', fontSize: '1.1rem' }}>INVOICE</h4>
                <p style={{ fontSize: '0.8rem', fontWeight: 700, color: '#0891b2' }}>{bill.bill_code}</p>
                <p style={{ fontSize: '0.75rem', color: '#64748b' }}>Date: {new Date(bill.created_at).toLocaleDateString()}</p>
              </div>
            </div>

            {/* Patient Details */}
            <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '8px', marginBottom: '1.5rem' }}>
              <span style={{ fontSize: '0.75rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 700 }}>Billed To</span>
              <div style={{ fontWeight: 700, fontSize: '1rem', color: '#0f172a' }}>{bill.patient_name}</div>
              <div style={{ fontSize: '0.8rem', color: '#475569' }}>Status: <strong style={{ color: bill.status === 'PAID' ? '#059669' : '#d97706' }}>{bill.status}</strong></div>
            </div>

            {/* Charges Table */}
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem', marginBottom: '1.5rem' }}>
              <thead>
                <tr style={{ background: '#e2e8f0', color: '#1e293b', textAlign: 'left' }}>
                  <th style={{ padding: '0.65rem 0.75rem' }}>Description</th>
                  <th style={{ padding: '0.65rem 0.75rem', textAlign: 'right' }}>Amount (₹)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0' }}>Doctor Consultation Fee</td>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0', textAlign: 'right' }}>₹{bill.consultation_fee}</td>
                </tr>
                <tr>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0' }}>Room / Bed Charges</td>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0', textAlign: 'right' }}>₹{bill.room_charges}</td>
                </tr>
                <tr>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0' }}>Laboratory Diagnostics</td>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0', textAlign: 'right' }}>₹{bill.lab_charges}</td>
                </tr>
                <tr>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0' }}>Pharmacy Medications</td>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0', textAlign: 'right' }}>₹{bill.pharmacy_charges}</td>
                </tr>
                <tr>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0' }}>Taxes (GST)</td>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0', textAlign: 'right' }}>+ ₹{bill.tax_amount}</td>
                </tr>
                <tr>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0', color: '#059669', fontWeight: 600 }}>Discount Applied</td>
                  <td style={{ padding: '0.65rem 0.75rem', borderBottom: '1px solid #e2e8f0', textAlign: 'right', color: '#059669', fontWeight: 600 }}>- ₹{bill.discount}</td>
                </tr>
              </tbody>
            </table>

            {/* Calculations Summary */}
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <div style={{ width: '250px', display: 'flex', flexDirection: 'column', gap: '0.4rem', fontSize: '0.9rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, fontSize: '1.1rem', color: '#0f172a', borderTop: '2px solid #0f172a', paddingTop: '0.5rem' }}>
                  <span>Total Bill:</span>
                  <span>₹{bill.total_amount}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#059669', fontWeight: 700 }}>
                  <span>Amount Paid:</span>
                  <span>₹{bill.paid_amount}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#dc2626', fontWeight: 800, fontSize: '1.05rem' }}>
                  <span>Balance Due:</span>
                  <span>₹{bill.balance_amount}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Payment Form */}
          {bill.status !== 'PAID' && (
            <div className="glass-card" style={{ background: 'rgba(30, 41, 59, 0.6)' }}>
              <h4 style={{ fontSize: '0.95rem', marginBottom: '1rem', color: '#fff', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <CreditCard size={18} color="#0891b2" /> Record Payment
              </h4>
              <form onSubmit={handlePaymentSubmit} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-end' }}>
                <div style={{ flex: 1 }}>
                  <label className="form-label">Payment Amount (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    placeholder={`Max ₹${bill.balance_amount}`}
                    value={payAmount}
                    onChange={e => setPayAmount(e.target.value)}
                    required
                  />
                </div>
                <div style={{ width: '150px' }}>
                  <label className="form-label">Method</label>
                  <select className="form-select" value={payMethod} onChange={e => setPayMethod(e.target.value)}>
                    <option value="UPI">UPI</option>
                    <option value="CARD">Credit/Debit Card</option>
                    <option value="CASH">Cash</option>
                    <option value="ONLINE">Online Banking</option>
                  </select>
                </div>
                <button type="submit" disabled={isProcessing} className="btn btn-success">
                  <CheckCircle2 size={16} /> Pay Now
                </button>
              </form>
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button onClick={downloadPDF} className="btn btn-primary">
            <Download size={16} /> Download Invoice PDF
          </button>
        </div>
      </div>
    </div>
  );
};
