import React from 'react';

export const StatCard = ({ title, value, icon: Icon, color = '#0891b2', trend, subtitle }) => {
  return (
    <div className="glass-card interactive" style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            {title}
          </span>
          <h2 style={{ fontSize: '1.85rem', fontWeight: 800, marginTop: '0.2rem', color: '#ffffff' }}>
            {value}
          </h2>
        </div>
        {Icon && (
          <div style={{
            background: `${color}20`,
            border: `1px solid ${color}40`,
            borderRadius: '12px',
            width: '46px',
            height: '46px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Icon size={24} color={color} />
          </div>
        )}
      </div>

      {(trend || subtitle) && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.75rem', color: '#64748b' }}>
          {trend && <span style={{ color: trend.startsWith('+') ? '#34d399' : '#f87171', fontWeight: 700 }}>{trend}</span>}
          {subtitle && <span>{subtitle}</span>}
        </div>
      )}
    </div>
  );
};
