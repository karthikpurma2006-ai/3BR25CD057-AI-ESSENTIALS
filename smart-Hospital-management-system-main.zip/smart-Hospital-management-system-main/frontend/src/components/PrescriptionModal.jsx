import React from 'react';
import { X, Printer, Download, Hospital } from 'lucide-react';
import html2pdf from 'html2pdf.js';

export const PrescriptionModal = ({ prescription, onClose }) => {
  if (!prescription) return null;

  const downloadPDF = () => {
    const element = document.getElementById('prescription-print-area');
    const opt = {
      margin: 0.5,
      filename: `${prescription.prescription_code}_prescription.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '700px', background: '#0f172a' }}>
        <div className="modal-header">
          <h3 style={{ fontSize: '1.1rem' }}>Prescription Details ({prescription.prescription_code})</h3>
          <button onClick={onClose} style={{ background: 'none', color: '#94a3b8' }}>
            <X size={20} />
          </button>
        </div>

        <div className="modal-body" id="prescription-print-area" style={{ background: '#ffffff', color: '#0f172a', padding: '2rem', borderRadius: '12px' }}>
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '2px solid #0891b2', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
            <div>
              <h2 style={{ color: '#0891b2', fontSize: '1.4rem', fontWeight: 800 }}>Sanjeevini Multispeciality Hospital</h2>
              <p style={{ fontSize: '0.8rem', color: '#475569' }}>124 Healthcare Boulevard, Cityville • Ph: +1 555-012-3456</p>
            </div>
            <div style={{ textAlign: 'right' }}>
              <h4 style={{ color: '#1e293b', fontSize: '1rem' }}>Rx Prescription</h4>
              <p style={{ fontSize: '0.8rem', color: '#64748b' }}>Date: {prescription.date}</p>
              <p style={{ fontSize: '0.8rem', fontWeight: 700, color: '#0891b2' }}>{prescription.prescription_code}</p>
            </div>
          </div>

          {/* Doctor & Patient Info */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', background: '#f8fafc', padding: '1rem', borderRadius: '8px', marginBottom: '1.5rem' }}>
            <div>
              <span style={{ fontSize: '0.75rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 700 }}>Doctor</span>
              <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#0f172a' }}>{prescription.doctor_name}</div>
            </div>
            <div>
              <span style={{ fontSize: '0.75rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 700 }}>Patient</span>
              <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#0f172a' }}>{prescription.patient_name}</div>
            </div>
          </div>

          {/* Diagnosis */}
          <div style={{ marginBottom: '1.5rem' }}>
            <h5 style={{ fontSize: '0.85rem', color: '#475569', textTransform: 'uppercase', marginBottom: '0.3rem' }}>Diagnosis</h5>
            <p style={{ background: '#f1f5f9', padding: '0.65rem 1rem', borderRadius: '6px', fontSize: '0.9rem', color: '#334155', fontWeight: 600 }}>
              {prescription.diagnosis}
            </p>
          </div>

          {/* Medicines Table */}
          <div style={{ marginBottom: '1.5rem' }}>
            <h5 style={{ fontSize: '0.85rem', color: '#475569', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Prescribed Medicines</h5>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: '#e2e8f0', color: '#1e293b', textAlign: 'left' }}>
                  <th style={{ padding: '0.5rem 0.75rem' }}>Medicine</th>
                  <th style={{ padding: '0.5rem 0.75rem' }}>Dosage</th>
                  <th style={{ padding: '0.5rem 0.75rem' }}>Frequency</th>
                  <th style={{ padding: '0.5rem 0.75rem' }}>Duration</th>
                  <th style={{ padding: '0.5rem 0.75rem' }}>Instructions</th>
                </tr>
              </thead>
              <tbody>
                {prescription.items && prescription.items.map((item, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #e2e8f0' }}>
                    <td style={{ padding: '0.65rem 0.75rem', fontWeight: 700, color: '#0f172a' }}>{item.medicine_name}</td>
                    <td style={{ padding: '0.65rem 0.75rem', color: '#334155' }}>{item.dosage}</td>
                    <td style={{ padding: '0.65rem 0.75rem', color: '#334155' }}>{item.frequency}</td>
                    <td style={{ padding: '0.65rem 0.75rem', color: '#334155' }}>{item.duration}</td>
                    <td style={{ padding: '0.65rem 0.75rem', color: '#475569' }}>{item.instructions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Footer Signature */}
          <div style={{ marginTop: '3rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
              Generated digitally by Sanjeevini Multispeciality Hospital. Valid without physical stamp.
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ borderBottom: '1px solid #94a3b8', width: '160px', marginBottom: '0.3rem' }}></div>
              <div style={{ fontSize: '0.8rem', fontWeight: 700, color: '#0f172a' }}>{prescription.doctor_name}</div>
              <div style={{ fontSize: '0.7rem', color: '#64748b' }}>Authorized Medical Practitioner</div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button onClick={downloadPDF} className="btn btn-primary">
            <Download size={16} /> Download PDF
          </button>
          <button onClick={handlePrint} className="btn btn-secondary">
            <Printer size={16} /> Print
          </button>
        </div>
      </div>
    </div>
  );
};
