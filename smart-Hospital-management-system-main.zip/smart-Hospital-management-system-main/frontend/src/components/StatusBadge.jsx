import React from 'react';

export const StatusBadge = ({ status }) => {
  const statusMap = {
    // Appointment & OPD
    'CONFIRMED': { label: 'Confirmed', class: 'badge-success' },
    'PENDING': { label: 'Pending', class: 'badge-warning' },
    'COMPLETED': { label: 'Completed', class: 'badge-primary' },
    'CANCELLED': { label: 'Cancelled', class: 'badge-danger' },
    'REJECTED': { label: 'Rejected', class: 'badge-danger' },
    'WAITING': { label: 'Waiting', class: 'badge-warning' },
    
    // Beds
    'AVAILABLE': { label: 'Available', class: 'badge-success' },
    'OCCUPIED': { label: 'Occupied', class: 'badge-danger' },
    'RESERVED': { label: 'Reserved', class: 'badge-warning' },
    'MAINTENANCE': { label: 'Maintenance', class: 'badge-secondary' },
    
    // Lab
    'REQUESTED': { label: 'Requested', class: 'badge-warning' },
    'SAMPLE_COLLECTED': { label: 'Sample Collected', class: 'badge-info' },
    'PROCESSING': { label: 'Processing', class: 'badge-primary' },
    
    // Billing
    'PAID': { label: 'Paid', class: 'badge-success' },
    'PARTIALLY_PAID': { label: 'Partially Paid', class: 'badge-warning' },
    
    // Emergency
    'CRITICAL': { label: 'Critical', class: 'badge-danger' },
    'HIGH': { label: 'High Priority', class: 'badge-warning' },
    'MEDIUM': { label: 'Medium', class: 'badge-info' },
    'LOW': { label: 'Low', class: 'badge-secondary' },
  };

  const item = statusMap[status] || { label: status, class: 'badge-secondary' };

  return <span className={`badge ${item.class}`}>{item.label}</span>;
};
