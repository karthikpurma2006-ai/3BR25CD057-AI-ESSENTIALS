import React from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  LayoutDashboard, Users, Stethoscope, Building2, Calendar, FileText,
  Pill, FlaskConical, BedDouble, Receipt, Package, Shield, Activity,
  Clock, AlertTriangle, UserCheck, HeartPulse, Sparkles
} from 'lucide-react';

export const Sidebar = ({ activeModule, setActiveModule }) => {
  const { user } = useAuth();
  const role = user?.role || 'PATIENT';

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['ALL'] },
    { id: 'patients', label: 'Patients', icon: Users, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'DOCTOR', 'NURSE', 'RECEPTIONIST'] },
    { id: 'doctors', label: 'Doctors', icon: Stethoscope, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'RECEPTIONIST', 'PATIENT'] },
    { id: 'departments', label: 'Departments', icon: Building2, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN'] },
    { id: 'appointments', label: 'Appointments', icon: Calendar, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'DOCTOR', 'RECEPTIONIST', 'PATIENT'] },
    { id: 'opd', label: 'OPD Tokens', icon: Clock, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'RECEPTIONIST', 'DOCTOR'] },
    { id: 'admissions', label: 'Admissions', icon: UserCheck, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'NURSE', 'RECEPTIONIST', 'DOCTOR'] },
    { id: 'wards', label: 'Wards & Beds', icon: BedDouble, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'NURSE', 'RECEPTIONIST', 'DOCTOR'] },
    { id: 'emr', label: 'Medical Records', icon: FileText, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'DOCTOR', 'NURSE', 'PATIENT'] },
    { id: 'prescriptions', label: 'Prescriptions', icon: HeartPulse, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'DOCTOR', 'PHARMACIST', 'PATIENT'] },
    { id: 'pharmacy', label: 'Pharmacy Stock', icon: Pill, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'PHARMACIST'] },
    { id: 'laboratory', label: 'Laboratory', icon: FlaskConical, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'LAB_STAFF', 'DOCTOR', 'PATIENT'] },
    { id: 'nursing', label: 'Nursing Vitals', icon: Activity, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'NURSE', 'DOCTOR'] },
    { id: 'emergency', label: 'Emergency', icon: AlertTriangle, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'NURSE', 'DOCTOR', 'RECEPTIONIST'] },
    { id: 'billing', label: 'Billing & Payments', icon: Receipt, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'ACCOUNTANT', 'RECEPTIONIST', 'PATIENT'] },
    { id: 'inventory', label: 'Inventory', icon: Package, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN'] },
    { id: 'staff', label: 'Staff Management', icon: Shield, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN'] },
    { id: 'reports', label: 'Reports & Analytics', icon: Sparkles, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN', 'ACCOUNTANT'] },
    { id: 'audit', label: 'Audit Logs', icon: Shield, roles: ['SUPER_ADMIN', 'HOSPITAL_ADMIN'] },
  ];

  const allowedItems = menuItems.filter(item => 
    item.roles.includes('ALL') || item.roles.includes(role)
  );

  return (
    <aside style={{
      width: '260px',
      background: 'rgba(15, 23, 42, 0.95)',
      backdropFilter: 'blur(16px)',
      borderRight: '1px solid rgba(255, 255, 255, 0.08)',
      display: 'flex',
      flexDirection: 'column',
      padding: '1.25rem 0.85rem',
      gap: '0.35rem',
      height: 'calc(100vh - 70px)',
      position: 'sticky',
      top: '70px',
      overflowY: 'auto'
    }}>
      <div style={{ padding: '0 0.75rem 0.75rem 0.75rem', fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
        Main Navigation
      </div>

      {allowedItems.map(item => {
        const Icon = item.icon;
        const isActive = activeModule === item.id;

        return (
          <button
            key={item.id}
            onClick={() => setActiveModule(item.id)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.85rem',
              width: '100%',
              padding: '0.7rem 0.85rem',
              borderRadius: '10px',
              color: isActive ? '#ffffff' : '#94a3b8',
              background: isActive ? 'linear-gradient(135deg, rgba(8, 145, 178, 0.3) 0%, rgba(79, 70, 229, 0.2) 100%)' : 'transparent',
              border: isActive ? '1px solid rgba(8, 145, 178, 0.5)' : '1px solid transparent',
              fontWeight: isActive ? 600 : 500,
              fontSize: '0.875rem',
              textAlign: 'left',
              transition: 'all 0.15s ease'
            }}
          >
            <Icon size={18} color={isActive ? '#22d3ee' : '#64748b'} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </aside>
  );
};
