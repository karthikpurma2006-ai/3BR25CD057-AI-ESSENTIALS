import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Bell, Search, User, LogOut, Activity, ShieldAlert,
  ChevronDown, CheckCircle2, Hospital
} from 'lucide-react';
import { api } from '../services/api';

export const Navbar = ({ onOpenSearch, activeModule, setActiveModule }) => {
  const { user, logout } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [showNotifDrawer, setShowNotifDrawer] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  useEffect(() => {
    if (user) {
      api.get('notifications')
        .then(data => setNotifications(data))
        .catch(() => {});
    }
  }, [user]);

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const markAllRead = () => {
    api.post('notifications/mark_all_read', {})
      .then(() => {
        setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      })
      .catch(() => {});
  };

  const roleColors = {
    'SUPER_ADMIN': 'badge-danger',
    'HOSPITAL_ADMIN': 'badge-warning',
    'DOCTOR': 'badge-primary',
    'NURSE': 'badge-success',
    'RECEPTIONIST': 'badge-info',
    'PHARMACIST': 'badge-warning',
    'LAB_STAFF': 'badge-info',
    'ACCOUNTANT': 'badge-secondary',
    'PATIENT': 'badge-success',
  };

  return (
    <header style={{
      height: '70px',
      background: 'rgba(15, 23, 42, 0.85)',
      backdropFilter: 'blur(16px)',
      borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
      padding: '0 2rem',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 100
    }}>
      {/* Brand & Module Title */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <div style={{
          background: 'linear-gradient(135deg, #0891b2 0%, #4f46e5 100%)',
          width: '38px',
          height: '38px',
          borderRadius: '10px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 0 15px rgba(8, 145, 178, 0.4)'
        }}>
          <Hospital size={22} color="#ffffff" />
        </div>
        <div>
          <h3 style={{ fontSize: '1.1rem', fontWeight: 800, background: 'linear-gradient(to right, #ffffff, #94a3b8)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            Sanjeevini Hospital
          </h3>
          <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
            {activeModule ? activeModule.replace('_', ' ') : 'Multispeciality Healthcare'}
          </p>
        </div>
      </div>

      {/* Search & Actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <button onClick={onOpenSearch} style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          background: 'rgba(30, 41, 59, 0.8)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: '20px',
          padding: '0.45rem 1rem',
          color: '#94a3b8',
          fontSize: '0.85rem'
        }}>
          <Search size={16} />
          <span>Search patients, doctors, records...</span>
          <kbd style={{ background: '#0f172a', padding: '2px 6px', borderRadius: '4px', fontSize: '0.7rem' }}>Ctrl+K</kbd>
        </button>

        {/* Notifications */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => setShowNotifDrawer(!showNotifDrawer)} style={{
            background: 'rgba(30, 41, 59, 0.8)',
            border: '1px solid rgba(255,255,255,0.08)',
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#cbd5e1',
            position: 'relative'
          }}>
            <Bell size={18} />
            {unreadCount > 0 && (
              <span style={{
                position: 'absolute',
                top: '6px',
                right: '6px',
                background: '#dc2626',
                color: '#fff',
                borderRadius: '50%',
                width: '16px',
                height: '16px',
                fontSize: '0.65rem',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>{unreadCount}</span>
            )}
          </button>

          {showNotifDrawer && (
            <div className="glass-card" style={{
              position: 'absolute',
              right: 0,
              top: '50px',
              width: '320px',
              maxHeight: '400px',
              overflowY: 'auto',
              zIndex: 200,
              padding: '1rem'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                <h4 style={{ fontSize: '0.9rem' }}>Notifications</h4>
                <button onClick={markAllRead} style={{ background: 'none', color: '#0891b2', fontSize: '0.75rem' }}>Mark read</button>
              </div>
              {notifications.length === 0 ? (
                <p style={{ fontSize: '0.8rem', color: '#64748b' }}>No notifications</p>
              ) : (
                notifications.map(n => (
                  <div key={n.id} style={{
                    padding: '0.6rem 0',
                    borderBottom: '1px solid rgba(255,255,255,0.05)',
                    opacity: n.is_read ? 0.6 : 1
                  }}>
                    <h5 style={{ fontSize: '0.825rem', color: '#f8fafc' }}>{n.title}</h5>
                    <p style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{n.message}</p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Profile Pill */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => setShowProfileMenu(!showProfileMenu)} style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            background: 'rgba(30, 41, 59, 0.8)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: '25px',
            padding: '0.35rem 0.85rem 0.35rem 0.35rem',
            color: '#ffffff'
          }}>
            <div style={{
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              background: '#0891b2',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
              fontSize: '0.85rem'
            }}>
              {user?.first_name ? user.first_name[0] : 'U'}
            </div>
            <div style={{ textAlign: 'left', lineHeight: 1.2 }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 600 }}>
                {user?.first_name ? `${user.first_name} ${user.last_name}` : user?.username}
              </div>
              <span className={`badge ${roleColors[user?.role] || 'badge-secondary'}`} style={{ fontSize: '0.6rem', padding: '1px 6px' }}>
                {user?.role?.replace('_', ' ')}
              </span>
            </div>
            <ChevronDown size={14} color="#94a3b8" />
          </button>

          {showProfileMenu && (
            <div className="glass-card" style={{
              position: 'absolute',
              right: 0,
              top: '50px',
              width: '200px',
              padding: '0.5rem',
              zIndex: 200
            }}>
              <div style={{ padding: '0.5rem 0.75rem', borderBottom: '1px solid rgba(255,255,255,0.08)', marginBottom: '0.5rem' }}>
                <div style={{ fontSize: '0.8rem', fontWeight: 600 }}>{user?.email}</div>
                <div style={{ fontSize: '0.7rem', color: '#64748b' }}>Role: {user?.role}</div>
              </div>
              <button onClick={logout} className="btn btn-danger btn-sm" style={{ width: '100%', justifyContent: 'flex-start' }}>
                <LogOut size={14} /> Log Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
