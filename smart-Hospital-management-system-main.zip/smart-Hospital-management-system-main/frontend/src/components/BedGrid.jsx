import React from 'react';
import { BedDouble, CheckCircle2, AlertCircle, Clock, Wrench } from 'lucide-react';

export const BedGrid = ({ wards, beds, onSelectBed }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'AVAILABLE': return { bg: 'rgba(5, 150, 105, 0.15)', border: 'rgba(5, 150, 105, 0.4)', text: '#34d399', icon: CheckCircle2 };
      case 'OCCUPIED': return { bg: 'rgba(220, 38, 38, 0.15)', border: 'rgba(220, 38, 38, 0.4)', text: '#f87171', icon: AlertCircle };
      case 'RESERVED': return { bg: 'rgba(217, 119, 6, 0.15)', border: 'rgba(217, 119, 6, 0.4)', text: '#fbbf24', icon: Clock };
      default: return { bg: 'rgba(148, 163, 184, 0.15)', border: 'rgba(148, 163, 184, 0.3)', text: '#cbd5e1', icon: Wrench };
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      {wards.map(ward => {
        const wardBeds = beds.filter(b => b.ward === ward.id || b.ward_name === ward.name);

        return (
          <div key={ward.id} className="glass-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.2rem', borderBottom: '1px solid rgba(255,255,255,0.08)', paddingBottom: '0.75rem' }}>
              <div>
                <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>{ward.name}</h3>
                <p style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Type: {ward.ward_type} • Daily Rate: ₹{ward.beds?.[0]?.daily_rate || 1000}</p>
              </div>
              <div style={{ display: 'flex', gap: '1rem', fontSize: '0.8rem' }}>
                <span style={{ color: '#34d399', fontWeight: 600 }}>Available: {wardBeds.filter(b => b.status === 'AVAILABLE').length}</span>
                <span style={{ color: '#f87171', fontWeight: 600 }}>Occupied: {wardBeds.filter(b => b.status === 'OCCUPIED').length}</span>
              </div>
            </div>

            <div className="grid-4" style={{ gap: '1rem' }}>
              {wardBeds.map(bed => {
                const info = getStatusColor(bed.status);
                const Icon = info.icon;

                return (
                  <div
                    key={bed.id}
                    onClick={() => onSelectBed && onSelectBed(bed)}
                    style={{
                      background: info.bg,
                      border: `1px solid ${info.border}`,
                      borderRadius: '12px',
                      padding: '1rem',
                      cursor: onSelectBed ? 'pointer' : 'default',
                      transition: 'transform 0.15s ease',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '0.5rem'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <BedDouble size={20} color={info.text} />
                        <span style={{ fontWeight: 700, fontSize: '0.95rem', color: '#fff' }}>{bed.bed_number}</span>
                      </div>
                      <Icon size={16} color={info.text} />
                    </div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: info.text, textTransform: 'uppercase' }}>
                      {bed.status}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
};
