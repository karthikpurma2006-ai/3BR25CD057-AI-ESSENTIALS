import React, { useState, useEffect } from 'react';
import { Search, X, User, Stethoscope, Pill, FlaskConical, Calendar } from 'lucide-react';
import { api } from '../services/api';

export const SearchModal = ({ isOpen, onClose, onSelectResult }) => {
  const [query, setQuery] = useState('');
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [labTests, setLabTests] = useState([]);

  useEffect(() => {
    if (isOpen) {
      api.get('patients').then(setPatients).catch(() => {});
      api.get('doctors').then(setDoctors).catch(() => {});
      api.get('medicines').then(setMedicines).catch(() => {});
      api.get('lab-tests').then(setLabTests).catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const q = query.toLowerCase();
  const filteredPatients = patients.filter(p => p.full_name?.toLowerCase().includes(q) || p.patient_id?.toLowerCase().includes(q));
  const filteredDoctors = doctors.filter(d => d.doctor_name?.toLowerCase().includes(q) || d.specialization?.toLowerCase().includes(q));
  const filteredMedicines = medicines.filter(m => m.name?.toLowerCase().includes(q) || m.medicine_code?.toLowerCase().includes(q));
  const filteredLabTests = labTests.filter(l => l.name?.toLowerCase().includes(q) || l.code?.toLowerCase().includes(q));

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '650px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '1rem 1.25rem', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <Search size={20} color="#0891b2" />
          <input
            type="text"
            placeholder="Search patients, doctors, medicines, lab tests..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            autoFocus
            style={{
              flex: 1,
              background: 'none',
              border: 'none',
              outline: 'none',
              color: '#fff',
              fontSize: '1rem'
            }}
          />
          <button onClick={onClose} style={{ background: 'none', color: '#94a3b8' }}>
            <X size={20} />
          </button>
        </div>

        <div style={{ maxHeight: '450px', overflowY: 'auto', padding: '1rem' }}>
          {query.trim() === '' ? (
            <p style={{ color: '#64748b', fontSize: '0.85rem', textAlign: 'center', padding: '2rem 0' }}>
              Type a name, ID, or keyword to search across Sanjeevini modules.
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {/* Patients */}
              {filteredPatients.length > 0 && (
                <div>
                  <h5 style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Patients</h5>
                  {filteredPatients.slice(0, 4).map(p => (
                    <div key={p.id} onClick={() => { onSelectResult && onSelectResult('patients', p); onClose(); }} style={{ padding: '0.5rem', borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.75rem', hover: { background: 'rgba(255,255,255,0.05)' } }}>
                      <User size={16} color="#0891b2" />
                      <div>
                        <div style={{ color: '#fff', fontSize: '0.9rem', fontWeight: 600 }}>{p.full_name} <span style={{ color: '#64748b', fontSize: '0.75rem' }}>({p.patient_id})</span></div>
                        <div style={{ color: '#94a3b8', fontSize: '0.75rem' }}>Age: {p.age} • Gender: {p.gender} • Phone: {p.phone}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Doctors */}
              {filteredDoctors.length > 0 && (
                <div>
                  <h5 style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Doctors</h5>
                  {filteredDoctors.slice(0, 4).map(d => (
                    <div key={d.id} onClick={() => { onSelectResult && onSelectResult('doctors', d); onClose(); }} style={{ padding: '0.5rem', borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <Stethoscope size={16} color="#34d399" />
                      <div>
                        <div style={{ color: '#fff', fontSize: '0.9rem', fontWeight: 600 }}>{d.doctor_name}</div>
                        <div style={{ color: '#94a3b8', fontSize: '0.75rem' }}>{d.specialization} • Fee: ₹{d.consultation_fee}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Medicines */}
              {filteredMedicines.length > 0 && (
                <div>
                  <h5 style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Pharmacy Stock</h5>
                  {filteredMedicines.slice(0, 4).map(m => (
                    <div key={m.id} onClick={() => { onSelectResult && onSelectResult('pharmacy', m); onClose(); }} style={{ padding: '0.5rem', borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <Pill size={16} color="#fbbf24" />
                      <div>
                        <div style={{ color: '#fff', fontSize: '0.9rem', fontWeight: 600 }}>{m.name}</div>
                        <div style={{ color: '#94a3b8', fontSize: '0.75rem' }}>Stock: {m.quantity} • Price: ₹{m.price}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
