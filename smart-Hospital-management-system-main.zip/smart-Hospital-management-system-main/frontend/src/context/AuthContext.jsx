import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('hms_token') || null);
  const [patientId, setPatientId] = useState(localStorage.getItem('hms_patient_id') || null);
  const [doctorId, setDoctorId] = useState(localStorage.getItem('hms_doctor_id') || null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      api.me()
        .then(data => {
          setUser(data.user);
          if (data.patient_id) {
            setPatientId(data.patient_id);
            localStorage.setItem('hms_patient_id', data.patient_id);
          }
          if (data.doctor_id) {
            setDoctorId(data.doctor_id);
            localStorage.setItem('hms_doctor_id', data.doctor_id);
          }
        })
        .catch(() => logout())
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [token]);

  const login = async (credentials) => {
    const data = await api.login(credentials);
    localStorage.setItem('hms_token', data.token);
    setToken(data.token);
    setUser(data.user);
    if (data.patient_id) {
      setPatientId(data.patient_id);
      localStorage.setItem('hms_patient_id', data.patient_id);
    }
    if (data.doctor_id) {
      setDoctorId(data.doctor_id);
      localStorage.setItem('hms_doctor_id', data.doctor_id);
    }
    return data.user;
  };

  const registerPatient = async (patientData) => {
    const data = await api.registerPatient(patientData);
    localStorage.setItem('hms_token', data.token);
    setToken(data.token);
    setUser(data.user);
    if (data.patient_id) {
      setPatientId(data.patient_id);
      localStorage.setItem('hms_patient_id', data.patient_id);
    }
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('hms_token');
    localStorage.removeItem('hms_patient_id');
    localStorage.removeItem('hms_doctor_id');
    setToken(null);
    setUser(null);
    setPatientId(null);
    setDoctorId(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, patientId, doctorId, loading, login, registerPatient, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
