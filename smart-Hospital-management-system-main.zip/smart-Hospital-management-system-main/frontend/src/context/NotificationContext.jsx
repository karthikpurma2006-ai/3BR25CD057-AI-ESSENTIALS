import React, { createContext, useContext, useState } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

const NotificationContext = createContext();

export const NotificationProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const addToast = (message, type = 'info', title = '') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type, title }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <NotificationContext.Provider value={{ addToast }}>
      {children}
      <div style={{
        position: 'fixed',
        bottom: '24px',
        right: '24px',
        zIndex: 9999,
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        maxWidth: '380px'
      }}>
        {toasts.map(toast => (
          <div key={toast.id} className="glass-card" style={{
            padding: '12px 16px',
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '12px',
            borderLeft: `4px solid ${
              toast.type === 'success' ? '#059669' :
              toast.type === 'error' ? '#dc2626' :
              toast.type === 'warning' ? '#d97706' : '#2563eb'
            }`,
            boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
            animation: 'fadeIn 0.3s ease'
          }}>
            {toast.type === 'success' && <CheckCircle2 color="#34d399" size={20} />}
            {toast.type === 'error' && <AlertCircle color="#f87171" size={20} />}
            {toast.type === 'warning' && <AlertCircle color="#fbbf24" size={20} />}
            {toast.type === 'info' && <Info color="#60a5fa" size={20} />}
            <div style={{ flex: 1 }}>
              {toast.title && <h5 style={{ fontSize: '0.85rem', marginBottom: '2px', color: '#fff' }}>{toast.title}</h5>}
              <p style={{ fontSize: '0.825rem', color: '#cbd5e1', margin: 0 }}>{toast.message}</p>
            </div>
            <button onClick={() => removeToast(toast.id)} style={{ background: 'none', color: '#94a3b8' }}>
              <X size={16} />
            </button>
          </div>
        ))}
      </div>
    </NotificationContext.Provider>
  );
};

export const useNotification = () => useContext(NotificationContext);
