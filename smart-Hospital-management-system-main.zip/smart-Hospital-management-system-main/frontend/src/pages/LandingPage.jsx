import React, { useState, useEffect } from 'react';
import { 
  Hospital, PhoneCall, Calendar, UserCheck, ShieldCheck, Stethoscope, 
  Activity, Clock, ChevronRight, Award, MapPin, Mail, ArrowRight, HeartPulse, LogIn
} from 'lucide-react';
import { api } from '../services/api';

export const LandingPage = ({ onOpenLogin, onOpenRegister, onBookAppointmentClick }) => {
  const [doctors, setDoctors] = useState([]);
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    api.get('doctors').then(setDoctors).catch(() => {});
    api.get('departments').then(setDepartments).catch(() => {});
  }, []);

  return (
    <div style={{ background: '#090d16', color: '#f8fafc', minHeight: '100vh' }}>
      {/* Header Navigation */}
      <nav style={{
        height: '80px',
        padding: '0 4rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: '1px solid rgba(255,255,255,0.08)',
        position: 'sticky',
        top: 0,
        background: 'rgba(9, 13, 22, 0.9)',
        backdropFilter: 'blur(16px)',
        zIndex: 100
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
          <div style={{
            background: 'linear-gradient(135deg, #0891b2 0%, #4f46e5 100%)',
            width: '42px',
            height: '42px',
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 20px rgba(8, 145, 178, 0.5)'
          }}>
            <Hospital size={24} color="#ffffff" />
          </div>
          <div>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#ffffff' }}>Sanjeevini Hospital</h2>
            <span style={{ fontSize: '0.65rem', color: '#0891b2', fontWeight: 700, letterSpacing: '0.08em' }}>MULTISPECIALITY HEALTHCARE</span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '2rem', fontSize: '0.95rem', fontWeight: 500 }}>
          <a href="#home" style={{ color: '#ffffff' }}>Home</a>
          <a href="#about" style={{ color: '#94a3b8' }}>About Us</a>
          <a href="#departments" style={{ color: '#94a3b8' }}>Departments</a>
          <a href="#doctors" style={{ color: '#94a3b8' }}>Doctors</a>
          <a href="#emergency" style={{ color: '#94a3b8' }}>Emergency</a>
        </div>

        <div style={{ display: 'flex', gap: '1rem' }}>
          <button onClick={onOpenLogin} className="btn btn-secondary">
            <LogIn size={16} /> Staff / Patient Login
          </button>
          <button onClick={onOpenRegister} className="btn btn-primary">
            Register as Patient
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" style={{
        padding: '6rem 4rem 4rem 4rem',
        display: 'grid',
        gridTemplateColumns: '1.2fr 0.8fr',
        gap: '4rem',
        alignItems: 'center'
      }}>
        <div>
          <div className="badge badge-primary" style={{ marginBottom: '1.5rem', padding: '0.4rem 1rem', fontSize: '0.85rem' }}>
            <HeartPulse size={16} /> 24/7 Advanced Medical Care & Hospital Operations
          </div>
          <h1 style={{ fontSize: '3.5rem', fontWeight: 800, lineHeight: 1.15, marginBottom: '1.5rem' }}>
            Complete Healthcare <br />
            <span style={{ background: 'linear-gradient(135deg, #22d3ee 0%, #818cf8 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Management in One Place
            </span>
          </h1>
          <p style={{ fontSize: '1.15rem', color: '#94a3b8', lineHeight: 1.6, marginBottom: '2.5rem', maxWidth: '600px' }}>
            Streamlining clinical workflows, electronic medical records, patient OPD check-ins, pharmacy inventory, real-time bed tracking, and billing operations into a single secure platform.
          </p>

          <div style={{ display: 'flex', gap: '1.25rem' }}>
            <button onClick={onBookAppointmentClick} className="btn btn-primary btn-lg">
              <Calendar size={20} /> Book Appointment
            </button>
            <a href="tel:1800-MEDICARE" className="btn btn-danger btn-lg">
              <PhoneCall size={20} /> Emergency 24/7
            </a>
          </div>
        </div>

        {/* Hero Card Visual */}
        <div className="glass-card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem', border: '1px solid rgba(8,145,178,0.3)', boxShadow: '0 20px 50px rgba(0,0,0,0.6)' }}>
          <h3 style={{ fontSize: '1.2rem', color: '#fff', borderBottom: '1px solid rgba(255,255,255,0.08)', paddingBottom: '0.75rem' }}>
            Quick Emergency Hotline
          </h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', background: 'rgba(220, 38, 38, 0.15)', border: '1px solid rgba(220,38,38,0.3)', padding: '1rem', borderRadius: '12px' }}>
            <PhoneCall size={32} color="#f87171" />
            <div>
              <div style={{ fontSize: '0.8rem', color: '#f87171', fontWeight: 700 }}>EMERGENCY TOLL FREE</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#fff' }}>+1 800 633 4227</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div style={{ background: 'rgba(15,23,42,0.8)', padding: '1rem', borderRadius: '10px' }}>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#22d3ee' }}>100+</div>
              <div style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Specialist Doctors</div>
            </div>
            <div style={{ background: 'rgba(15,23,42,0.8)', padding: '1rem', borderRadius: '10px' }}>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#34d399' }}>50,000+</div>
              <div style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Patients Healed</div>
            </div>
          </div>
        </div>
      </section>

      {/* Hospital Departments */}
      <section id="departments" style={{ padding: '5rem 4rem', background: 'rgba(15, 23, 42, 0.5)' }}>
        <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 3.5rem auto' }}>
          <span className="badge badge-primary" style={{ marginBottom: '0.5rem' }}>SPECIALIZED CARE</span>
          <h2 style={{ fontSize: '2.25rem', fontWeight: 800 }}>Clinical Departments</h2>
        </div>

        <div className="grid-3">
          {departments.map(dept => (
            <div key={dept.id} className="glass-card interactive" style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(8,145,178,0.2)', border: '1px solid rgba(8,145,178,0.4)', display: 'flex', alignItems: 'center', justifyCenter: 'center', marginBottom: '0.5rem' }}>
                <Stethoscope size={24} color="#22d3ee" />
              </div>
              <h3 style={{ fontSize: '1.2rem', color: '#fff' }}>{dept.name}</h3>
              <p style={{ fontSize: '0.85rem', color: '#94a3b8', lineHeight: 1.5 }}>{dept.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Doctors */}
      <section id="doctors" style={{ padding: '5rem 4rem' }}>
        <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 3.5rem auto' }}>
          <span className="badge badge-success" style={{ marginBottom: '0.5rem' }}>EXPERT SPECIALISTS</span>
          <h2 style={{ fontSize: '2.25rem', fontWeight: 800 }}>Our Featured Doctors</h2>
        </div>

        <div className="grid-4">
          {doctors.slice(0, 4).map(doc => (
            <div key={doc.id} className="glass-card interactive" style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{ width: '80px', height: '80px', borderRadius: '50%', background: '#0891b2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.75rem', fontWeight: 800, color: '#fff', boxShadow: '0 0 20px rgba(8,145,178,0.4)' }}>
                {doc.doctor_name?.[4] || 'D'}
              </div>
              <h4 style={{ fontSize: '1.1rem', color: '#fff' }}>{doc.doctor_name}</h4>
              <span className="badge badge-primary" style={{ fontSize: '0.7rem' }}>{doc.specialization}</span>
              <p style={{ fontSize: '0.8rem', color: '#94a3b8' }}>{doc.qualification} • {doc.experience_years} yrs exp</p>
              <button onClick={onBookAppointmentClick} className="btn btn-secondary btn-sm" style={{ width: '100%', marginTop: '0.5rem' }}>
                Book Consultation (₹{doc.consultation_fee})
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '3rem 4rem', borderTop: '1px solid rgba(255,255,255,0.08)', background: '#090d16', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <Hospital size={24} color="#0891b2" />
          <span style={{ fontWeight: 700, fontSize: '1rem', color: '#fff' }}>Sanjeevini Multispeciality Hospital Management System</span>
        </div>
        <div style={{ fontSize: '0.85rem', color: '#64748b' }}>
          © 2026 Sanjeevini HMS. Engineering Final-Year Academic Project.
        </div>
      </footer>
    </div>
  );
};
