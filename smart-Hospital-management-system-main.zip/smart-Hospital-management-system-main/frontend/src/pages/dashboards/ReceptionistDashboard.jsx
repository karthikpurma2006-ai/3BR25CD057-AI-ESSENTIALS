import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatCard } from '../../components/StatCard';
import { StatusBadge } from '../../components/StatusBadge';
import { Users, Clock, Calendar, UserPlus, Ticket } from 'lucide-react';

export const ReceptionistDashboard = ({ setActiveModule }) => {
  const [tokens, setTokens] = useState([]);
  const [patients, setPatients] = useState([]);
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    api.get('opd-tokens').then(setTokens).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
    api.get('appointments').then(setAppointments).catch(() => {});
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      <div className="grid-4">
        <StatCard title="OPD Tokens Today" value={tokens.length} icon={Ticket} color="#0891b2" />
        <StatCard title="Registered Patients" value={patients.length} icon={Users} color="#34d399" />
        <StatCard title="Appointments Today" value={appointments.length} icon={Calendar} color="#fbbf24" />
        <StatCard title="Waiting in OPD" value={tokens.filter(t => t.status === 'WAITING').length} icon={Clock} color="#818cf8" />
      </div>

      <div className="glass-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Live OPD Token Queue</h3>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button onClick={() => setActiveModule('patients')} className="btn btn-secondary btn-sm">
              <UserPlus size={16} /> Register Patient
            </button>
            <button onClick={() => setActiveModule('opd')} className="btn btn-primary btn-sm">
              <Ticket size={16} /> Issue OPD Token
            </button>
          </div>
        </div>

        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Token #</th>
                <th>Patient Name</th>
                <th>Assigned Doctor</th>
                <th>Fee</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {tokens.map(tok => (
                <tr key={tok.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>#{tok.token_number}</td>
                  <td style={{ fontWeight: 600 }}>{tok.patient_name}</td>
                  <td>{tok.doctor_name}</td>
                  <td>₹{tok.consultation_fee}</td>
                  <td><StatusBadge status={tok.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
