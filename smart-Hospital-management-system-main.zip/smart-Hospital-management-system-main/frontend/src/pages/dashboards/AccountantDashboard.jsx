import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatCard } from '../../components/StatCard';
import { StatusBadge } from '../../components/StatusBadge';
import { DollarSign, Receipt, CreditCard, Clock } from 'lucide-react';
import { BillInvoiceModal } from '../../components/BillInvoiceModal';

export const AccountantDashboard = ({ setActiveModule }) => {
  const [bills, setBills] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);

  const fetchBills = () => {
    api.get('bills').then(setBills).catch(() => {});
  };

  useEffect(() => {
    fetchBills();
  }, []);

  const totalRevenue = bills.reduce((acc, b) => acc + (parseFloat(b.paid_amount) || 0), 0);
  const totalPending = bills.reduce((acc, b) => acc + (parseFloat(b.balance_amount) || 0), 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      <div className="grid-4">
        <StatCard title="Total Bills" value={bills.length} icon={Receipt} color="#0891b2" />
        <StatCard title="Collected Revenue" value={`₹${totalRevenue.toLocaleString()}`} icon={DollarSign} color="#34d399" />
        <StatCard title="Pending Payments" value={`₹${totalPending.toLocaleString()}`} icon={Clock} color="#f87171" />
        <StatCard title="Paid Invoices" value={bills.filter(b => b.status === 'PAID').length} icon={CreditCard} color="#818cf8" />
      </div>

      <div className="glass-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Patient Billing & Invoices</h3>
          <button onClick={() => setActiveModule('billing')} className="btn btn-primary btn-sm">
            <Receipt size={16} /> Generate New Bill
          </button>
        </div>

        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Bill Code</th>
                <th>Patient</th>
                <th>Total Amount</th>
                <th>Paid Amount</th>
                <th>Balance Due</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {bills.map(b => (
                <tr key={b.id}>
                  <td style={{ fontWeight: 700, color: '#22d3ee' }}>{b.bill_code}</td>
                  <td>{b.patient_name}</td>
                  <td style={{ fontWeight: 700 }}>₹{b.total_amount}</td>
                  <td style={{ color: '#34d399' }}>₹{b.paid_amount}</td>
                  <td style={{ color: '#f87171', fontWeight: 700 }}>₹{b.balance_amount}</td>
                  <td><StatusBadge status={b.status} /></td>
                  <td>
                    <button onClick={() => setSelectedBill(b)} className="btn btn-secondary btn-sm">
                      Collect Payment / Invoice
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedBill && (
        <BillInvoiceModal bill={selectedBill} onClose={() => setSelectedBill(null)} onRefresh={fetchBills} />
      )}
    </div>
  );
};
