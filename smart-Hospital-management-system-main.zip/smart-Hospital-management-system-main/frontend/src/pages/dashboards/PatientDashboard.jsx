import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { StatCard } from '../../components/StatCard';
import { StatusBadge } from '../../components/StatusBadge';
import { Calendar, HeartPulse, FlaskConical, Receipt, Download, Plus } from 'lucide-react';
import { PrescriptionModal } from '../../components/PrescriptionModal';

export const PatientDashboard = ({ setActiveModule }) => {
  const { user, patientId } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);
  const [labReports, setLabReports] = useState([]);
  const [bills, setBills] = useState([]);
  const [selectedRx, setSelectedRx] = useState(null);

  useEffect(() => {
    api.get('appointments').then(data => {
      if (patientId) {
        setAppointments(data.filter(a => String(a.patient) === String(patientId)));
      } else {
        setAppointments(data.slice(0, 3));
      }
    }).catch(() => {});

    api.get('prescriptions').then(data => setPrescriptions(data)).catch(() => {});
    api.get('lab-reports').then(data => setLabReports(data)).catch(() => {});
    api.get('bills').then(data => setBills(data)).catch(() => {});
  }, [patientId]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      {/* Patient Welcome Banner */}
      <div className="glass-card" style={{ background: 'linear-gradient(135deg, rgba(8,145,178,0.2) 0%, rgba(79,70,229,0.2) 100%)', border: '1px solid rgba(8,145,178,0.4)', padding: '2rem' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Welcome to Your Health Portal, {user?.first_name || user?.username}!</h2>
        <p style={{ color: '#94a3b8', marginTop: '0.5rem', maxWidth: '600px' }}>
          View your upcoming doctor appointments, download electronic prescriptions, review lab reports, and manage hospital invoices seamlessly.
        </p>
        <button onClick={() => setActiveModule('appointments')} className="btn btn-primary btn-lg" style={{ marginTop: '1.25rem' }}>
          <Plus size={18} /> Book New Appointment
        </button>
      </div>

      <div className="grid-4">
        <StatCard title="My Appointments" value={appointments.length} icon={Calendar} color="#0891b2" />
        <StatCard title="My Prescriptions" value={prescriptions.length} icon={HeartPulse} color="#34d399" />
        <StatCard title="Lab Reports" value={labReports.length} icon={FlaskConical} color="#fbbf24" />
        <StatCard title="Medical Bills" value={bills.length} icon={Receipt} color="#818cf8" />
      </div>

      {/* Upcoming Appointments */}
      <div className="glass-card">
        <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', color: '#fff' }}>Upcoming Doctor Appointments</h3>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Appt Code</th>
                <th>Doctor Name</th>
                <th>Department</th>
                <th>Date & Time</th>
                <th>Reason</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map(apt => (
                <tr key={apt.id}>
                  <td style={{ fontWeight: 700, color: '#22d3ee' }}>{apt.appointment_id}</td>
                  <td style={{ fontWeight: 600 }}>{apt.doctor_name}</td>
                  <td>{apt.department_name}</td>
                  <td>{apt.date} at {apt.time_slot}</td>
                  <td>{apt.reason}</td>
                  <td><StatusBadge status={apt.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Prescriptions Section */}
      <div className="glass-card">
        <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', color: '#fff' }}>My Digital Prescriptions</h3>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Rx Code</th>
                <th>Doctor</th>
                <th>Date</th>
                <th>Diagnosis</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {prescriptions.map(rx => (
                <tr key={rx.id}>
                  <td style={{ fontWeight: 700, color: '#22d3ee' }}>{rx.prescription_code}</td>
                  <td>{rx.doctor_name}</td>
                  <td>{rx.date}</td>
                  <td>{rx.diagnosis}</td>
                  <td>
                    <button onClick={() => setSelectedRx(rx)} className="btn btn-primary btn-sm">
                      <Download size={14} /> View / Download PDF
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedRx && (
        <PrescriptionModal prescription={selectedRx} onClose={() => setSelectedRx(null)} />
      )}
    </div>
  );
};
