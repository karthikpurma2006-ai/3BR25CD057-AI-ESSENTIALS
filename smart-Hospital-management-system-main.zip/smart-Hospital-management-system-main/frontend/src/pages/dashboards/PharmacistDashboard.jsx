import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatCard } from '../../components/StatCard';
import { Pill, AlertTriangle, Clock, CheckCircle2 } from 'lucide-react';

export const PharmacistDashboard = ({ setActiveModule }) => {
  const [medicines, setMedicines] = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);

  useEffect(() => {
    api.get('medicines').then(setMedicines).catch(() => {});
    api.get('prescriptions').then(setPrescriptions).catch(() => {});
  }, []);

  const lowStock = medicines.filter(m => m.quantity <= m.min_threshold);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      <div className="grid-4">
        <StatCard title="Total Medicines" value={medicines.length} icon={Pill} color="#0891b2" />
        <StatCard title="Low Stock Alerts" value={lowStock.length} icon={AlertTriangle} color="#f87171" />
        <StatCard title="Active Prescriptions" value={prescriptions.filter(p => p.status === 'ACTIVE').length} icon={Clock} color="#fbbf24" />
        <StatCard title="Dispensed Today" value={prescriptions.filter(p => p.status === 'DISPENSED').length} icon={CheckCircle2} color="#34d399" />
      </div>

      <div className="glass-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Pending Prescriptions Queue</h3>
          <button onClick={() => setActiveModule('pharmacy')} className="btn btn-primary btn-sm">
            <Pill size={16} /> Manage Medicine Stock
          </button>
        </div>

        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Rx Code</th>
                <th>Patient</th>
                <th>Prescribed By</th>
                <th>Medicines Count</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {prescriptions.map(rx => (
                <tr key={rx.id}>
                  <td style={{ fontWeight: 700, color: '#22d3ee' }}>{rx.prescription_code}</td>
                  <td>{rx.patient_name}</td>
                  <td>{rx.doctor_name}</td>
                  <td>{rx.items?.length || 0} medicines</td>
                  <td><span className="badge badge-warning">{rx.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
