import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatCard } from '../../components/StatCard';
import { StatusBadge } from '../../components/StatusBadge';
import { 
  Users, Stethoscope, BedDouble, Calendar, DollarSign, Pill, 
  FlaskConical, AlertTriangle, Activity, ArrowUpRight, Building2,
  Clock, UserCheck, HeartPulse, Receipt, Package, Shield, Sparkles, Plus
} from 'lucide-react';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

export const SuperAdminDashboard = ({ setActiveModule }) => {
  const [stats, setStats] = useState({
    total_patients: 10,
    total_doctors: 10,
    total_staff: 15,
    today_appointments: 8,
    today_admissions: 1,
    available_beds: 29,
    occupied_beds: 3,
    pending_bills: 1,
    low_stock_medicines: 2,
    pending_lab_tests: 1,
    active_emergencies: 1,
    total_revenue: 3000.00,
    department_distribution: [
      { name: 'Cardiology', doc_count: 2 },
      { name: 'Neurology', doc_count: 2 },
      { name: 'Orthopedics', doc_count: 2 },
      { name: 'Pediatrics', doc_count: 2 },
      { name: 'General Medicine', doc_count: 2 }
    ]
  });
  
  const [recentAppts, setRecentAppts] = useState([]);
  const [emergencies, setEmergencies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getDashboardStats()
      .then(data => {
        if (data && typeof data === 'object') {
          setStats(prev => ({ ...prev, ...data }));
        }
      })
      .catch(err => console.error("Stats load error:", err))
      .finally(() => setLoading(false));

    api.get('appointments')
      .then(data => setRecentAppts(Array.isArray(data) ? data.slice(0, 5) : []))
      .catch(() => {});

    api.get('emergencies')
      .then(data => setEmergencies(Array.isArray(data) ? data.slice(0, 4) : []))
      .catch(() => {});
  }, []);

  const barData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
    datasets: [{
      label: 'Patient Admissions',
      data: [42, 58, 65, 78, 90, 85, 110],
      backgroundColor: 'rgba(8, 145, 178, 0.7)',
      borderRadius: 6
    }]
  };

  const doughnutData = {
    labels: stats.department_distribution?.map(d => d.name) || ['Cardiology', 'Neurology', 'Orthopedics', 'Pediatrics'],
    datasets: [{
      data: stats.department_distribution?.map(d => d.doc_count) || [4, 3, 3, 2],
      backgroundColor: ['#0891b2', '#4f46e5', '#059669', '#d97706', '#dc2626']
    }]
  };

  const adminActions = [
    { label: 'Register Patient', icon: Users, module: 'patients', color: '#0891b2' },
    { label: 'Manage Doctors', icon: Stethoscope, module: 'doctors', color: '#34d399' },
    { label: 'Book Appointment', icon: Calendar, module: 'appointments', color: '#fbbf24' },
    { label: 'Issue OPD Token', icon: Clock, module: 'opd', color: '#818cf8' },
    { label: 'Inpatient Admissions', icon: UserCheck, module: 'admissions', color: '#f87171' },
    { label: 'Wards & Beds Grid', icon: BedDouble, module: 'wards', color: '#60a5fa' },
    { label: 'Electronic Medical Records', icon: Activity, module: 'emr', color: '#a78bfa' },
    { label: 'Prescriptions Builder', icon: HeartPulse, module: 'prescriptions', color: '#f472b6' },
    { label: 'Pharmacy Stock', icon: Pill, module: 'pharmacy', color: '#fbbf24' },
    { label: 'Laboratory Tests', icon: FlaskConical, module: 'laboratory', color: '#38bdf8' },
    { label: 'Billing & Collection', icon: Receipt, module: 'billing', color: '#34d399' },
    { label: 'Hospital Inventory', icon: Package, module: 'inventory', color: '#fb7185' },
    { label: 'Staff Management', icon: Shield, module: 'staff', color: '#c084fc' },
    { label: 'Reports & Analytics', icon: Sparkles, module: 'reports', color: '#38bdf8' },
    { label: 'Audit Trail Logs', icon: Shield, module: 'audit', color: '#f43f5e' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      {/* Admin Quick Control Panel */}
      <div className="glass-card" style={{ background: 'linear-gradient(135deg, rgba(15,23,42,0.9) 0%, rgba(30,41,59,0.9) 100%)', border: '1px solid rgba(8,145,178,0.3)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <div>
            <h3 style={{ fontSize: '1.25rem', color: '#fff', fontWeight: 800 }}>Hospital Administrator Command Center</h3>
            <p style={{ fontSize: '0.825rem', color: '#94a3b8' }}>Full administrative privileges to launch, manage, and audit all hospital operations</p>
          </div>
          <span className="badge badge-danger" style={{ padding: '0.4rem 0.8rem' }}>Full Access Granted</span>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.6rem' }}>
          {adminActions.map((act, idx) => {
            const Icon = act.icon;
            return (
              <button
                key={idx}
                onClick={() => setActiveModule(act.module)}
                className="btn btn-secondary btn-sm"
                style={{
                  fontSize: '0.825rem',
                  padding: '0.5rem 0.85rem',
                  borderColor: 'rgba(255,255,255,0.1)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem'
                }}
              >
                <Icon size={15} color={act.color} />
                <span>{act.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Top Metric Cards */}
      <div className="grid-4">
        <StatCard title="Total Patients" value={stats.total_patients} icon={Users} color="#0891b2" trend="+14% this mo" />
        <StatCard title="Active Doctors" value={stats.total_doctors} icon={Stethoscope} color="#34d399" subtitle="Across 5 Depts" />
        <StatCard title="Today Appointments" value={stats.today_appointments} icon={Calendar} color="#fbbf24" trend="+8 today" />
        <StatCard title="Total Revenue" value={`₹${stats.total_revenue.toLocaleString()}`} icon={DollarSign} color="#818cf8" trend="+22% vs last mo" />
      </div>

      {/* Second Row Operational Cards */}
      <div className="grid-4">
        <StatCard title="Available Beds" value={`${stats.available_beds} / ${stats.available_beds + stats.occupied_beds}`} icon={BedDouble} color="#34d399" />
        <StatCard title="Active Emergencies" value={stats.active_emergencies} icon={AlertTriangle} color="#f87171" subtitle="Requires Immediate Action" />
        <StatCard title="Low Pharmacy Stock" value={stats.low_stock_medicines} icon={Pill} color="#fbbf24" subtitle="Medicines Alert" />
        <StatCard title="Pending Lab Tests" value={stats.pending_lab_tests} icon={FlaskConical} color="#60a5fa" />
      </div>

      {/* Analytics Charts Row */}
      <div className="grid-2">
        <div className="glass-card">
          <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', color: '#fff' }}>Patient Admissions Trend</h3>
          <Bar data={barData} options={{ responsive: true, plugins: { legend: { display: false } } }} />
        </div>
        <div className="glass-card">
          <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem', color: '#fff' }}>Doctors Distribution by Department</h3>
          <div style={{ maxHeight: '240px', display: 'flex', justifyContent: 'center' }}>
            <Doughnut data={doughnutData} options={{ responsive: true, maintainAspectRatio: false }} />
          </div>
        </div>
      </div>

      {/* Recent Appointments & Emergency Cases */}
      <div className="grid-2">
        <div className="glass-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Today's Recent Appointments</h3>
            <button onClick={() => setActiveModule('appointments')} className="btn btn-secondary btn-sm">
              View All <ArrowUpRight size={14} />
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Doctor</th>
                  <th>Time</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentAppts.map(apt => (
                  <tr key={apt.id}>
                    <td style={{ fontWeight: 600 }}>{apt.patient_name}</td>
                    <td>{apt.doctor_name}</td>
                    <td>{apt.time_slot}</td>
                    <td><StatusBadge status={apt.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="glass-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Active Emergency Cases</h3>
            <button onClick={() => setActiveModule('emergency')} className="btn btn-danger btn-sm">
              Manage Emergency
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Priority</th>
                  <th>Assigned Dr</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {emergencies.map(emg => (
                  <tr key={emg.id}>
                    <td style={{ fontWeight: 600 }}>{emg.patient_name} ({emg.age} y)</td>
                    <td><StatusBadge status={emg.priority} /></td>
                    <td>{emg.doctor_name}</td>
                    <td><span className="badge badge-danger">{emg.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
