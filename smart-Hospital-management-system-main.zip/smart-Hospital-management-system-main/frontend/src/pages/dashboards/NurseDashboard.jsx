import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatCard } from '../../components/StatCard';
import { BedGrid } from '../../components/BedGrid';
import { BedDouble, Activity, AlertTriangle, UserCheck } from 'lucide-react';

export const NurseDashboard = ({ setActiveModule }) => {
  const [wards, setWards] = useState([]);
  const [beds, setBeds] = useState([]);
  const [vitals, setVitals] = useState([]);

  useEffect(() => {
    api.get('wards').then(setWards).catch(() => {});
    api.get('beds').then(setBeds).catch(() => {});
    api.get('nursing-vitals').then(setVitals).catch(() => {});
  }, []);

  const occupiedBeds = beds.filter(b => b.status === 'OCCUPIED');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      <div className="grid-4">
        <StatCard title="Total Ward Beds" value={beds.length} icon={BedDouble} color="#0891b2" />
        <StatCard title="Currently Occupied" value={occupiedBeds.length} icon={UserCheck} color="#f87171" />
        <StatCard title="Available Beds" value={beds.length - occupiedBeds.length} icon={BedDouble} color="#34d399" />
        <StatCard title="Vitals Logged Today" value={vitals.length} icon={Activity} color="#818cf8" />
      </div>

      {/* Ward & Bed Status */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontSize: '1.2rem', color: '#fff' }}>Ward Bed Occupancy Status</h3>
          <button onClick={() => setActiveModule('nursing')} className="btn btn-primary btn-sm">
            <Activity size={16} /> Record Patient Vitals
          </button>
        </div>
        <BedGrid wards={wards} beds={beds} />
      </div>
    </div>
  );
};
