import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatCard } from '../../components/StatCard';
import { StatusBadge } from '../../components/StatusBadge';
import { FlaskConical, Clock, CheckCircle2, AlertCircle } from 'lucide-react';

export const LabStaffDashboard = ({ setActiveModule }) => {
  const [reports, setReports] = useState([]);
  const [labTests, setLabTests] = useState([]);

  useEffect(() => {
    api.get('lab-reports').then(setReports).catch(() => {});
    api.get('lab-tests').then(setLabTests).catch(() => {});
  }, []);

  const requested = reports.filter(r => r.status === 'REQUESTED');
  const completed = reports.filter(r => r.status === 'COMPLETED');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      <div className="grid-4">
        <StatCard title="Available Lab Tests" value={labTests.length} icon={FlaskConical} color="#0891b2" />
        <StatCard title="Test Requests Pending" value={requested.length} icon={Clock} color="#fbbf24" />
        <StatCard title="Completed Reports" value={completed.length} icon={CheckCircle2} color="#34d399" />
        <StatCard title="Total Lab Requests" value={reports.length} icon={AlertCircle} color="#818cf8" />
      </div>

      <div className="glass-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Diagnostic Test Tracker</h3>
          <button onClick={() => setActiveModule('laboratory')} className="btn btn-primary btn-sm">
            <FlaskConical size={16} /> Open Lab Module
          </button>
        </div>

        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Lab Report Code</th>
                <th>Patient</th>
                <th>Test Name</th>
                <th>Requested Doctor</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {reports.map(rep => (
                <tr key={rep.id}>
                  <td style={{ fontWeight: 700, color: '#22d3ee' }}>{rep.report_code}</td>
                  <td>{rep.patient_name}</td>
                  <td style={{ fontWeight: 600 }}>{rep.test_name}</td>
                  <td>{rep.doctor_name}</td>
                  <td><StatusBadge status={rep.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
