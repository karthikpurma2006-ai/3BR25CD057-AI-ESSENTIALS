import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { StatCard } from '../../components/StatCard';
import { StatusBadge } from '../../components/StatusBadge';
import { Calendar, User, FileText, HeartPulse, FlaskConical, CheckCircle2 } from 'lucide-react';
import { PrescriptionModal } from '../../components/PrescriptionModal';

export const DoctorDashboard = ({ setActiveModule }) => {
  const { doctorId } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]);
  const [selectedPrescription, setSelectedPrescription] = useState(null);

  useEffect(() => {
    api.get('appointments').then(data => {
      // Filter doctor's appointments if doctorId exists
      if (doctorId) {
        setAppointments(data.filter(a => String(a.doctor) === String(doctorId)));
      } else {
        setAppointments(data);
      }
    }).catch(() => {});

    api.get('patients').then(setPatients).catch(() => {});
  }, [doctorId]);

  const pendingAppts = appointments.filter(a => a.status === 'PENDING' || a.status === 'CONFIRMED');
  const completedAppts = appointments.filter(a => a.status === 'COMPLETED');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      <div className="grid-4">
        <StatCard title="My Appointments" value={appointments.length} icon={Calendar} color="#0891b2" />
        <StatCard title="Pending Consultations" value={pendingAppts.length} icon={User} color="#fbbf24" />
        <StatCard title="Completed Consultations" value={completedAppts.length} icon={CheckCircle2} color="#34d399" />
        <StatCard title="Total Patients" value={patients.length} icon={HeartPulse} color="#818cf8" />
      </div>

      {/* Appointments List */}
      <div className="glass-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Consultation Queue</h3>
          <button onClick={() => setActiveModule('prescriptions')} className="btn btn-primary btn-sm">
            <HeartPulse size={16} /> Create Prescription
          </button>
        </div>

        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Patient</th>
                <th>Date & Time</th>
                <th>Reason for Visit</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map(apt => (
                <tr key={apt.id}>
                  <td style={{ fontWeight: 700, color: '#fff' }}>{apt.patient_name}</td>
                  <td>{apt.date} at {apt.time_slot}</td>
                  <td>{apt.reason}</td>
                  <td><StatusBadge status={apt.status} /></td>
                  <td style={{ display: 'flex', gap: '0.5rem' }}>
                    <button onClick={() => setActiveModule('emr')} className="btn btn-secondary btn-sm">
                      <FileText size={14} /> EMR History
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
