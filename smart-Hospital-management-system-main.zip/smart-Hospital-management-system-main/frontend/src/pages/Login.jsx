import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import { Hospital, Lock, User, ArrowRight, ShieldCheck } from 'lucide-react';

export const Login = ({ onClose, onSwitchToRegister }) => {
  const { login } = useAuth();
  const { addToast } = useNotification();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const demoAccounts = [
    { role: 'Super Admin', username: 'admin', label: 'Super Admin' },
    { role: 'Hospital Admin', username: 'hospadmin', label: 'Admin' },
    { role: 'Doctor', username: 'dr.smith', label: 'Doctor' },
    { role: 'Nurse', username: 'nurse.sarah', label: 'Nurse' },
    { role: 'Receptionist', username: 'receptionist', label: 'Receptionist' },
    { role: 'Pharmacist', username: 'pharmacist', label: 'Pharmacist' },
    { role: 'Lab Staff', username: 'labtech', label: 'Lab Tech' },
    { role: 'Accountant', username: 'accountant', label: 'Accountant' },
    { role: 'Patient', username: 'patient.john', label: 'Patient' },
  ];

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login({ username, password });
      addToast(`Welcome back, ${user.first_name || user.username}!`, 'success', 'Logged In');
      if (onClose) onClose();
    } catch (err) {
      addToast(err.message || 'Invalid username or password', 'error', 'Login Failed');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoClick = (account) => {
    setUsername(account.username);
    setPassword('Password123!');
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '520px', padding: '0.5rem' }}>
        <div style={{ padding: '2rem 2rem 1rem 2rem', textAlign: 'center' }}>
          <div style={{
            width: '54px',
            height: '54px',
            borderRadius: '16px',
            background: 'linear-gradient(135deg, #0891b2 0%, #4f46e5 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 1rem auto',
            boxShadow: '0 0 25px rgba(8,145,178,0.5)'
          }}>
            <Hospital size={30} color="#fff" />
          </div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#fff' }}>Sanjeevini Portal Login</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.3rem' }}>
            Access your role-based dashboard & hospital modules
          </p>
        </div>

        {/* Demo Roles Quick Select Buttons */}
        <div style={{ padding: '0 2rem 1.25rem 2rem' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#0891b2', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
            ⚡ Demo Accounts (1-Click Fill)
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
            {demoAccounts.map((acc, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleDemoClick(acc)}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.725rem', padding: '0.25rem 0.6rem' }}
              >
                {acc.label}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleLoginSubmit} style={{ padding: '0 2rem 2rem 2rem' }}>
          <div className="form-group">
            <label className="form-label">Username or Email</label>
            <div style={{ position: 'relative' }}>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. admin or dr.smith"
                value={username}
                onChange={e => setUsername(e.target.value)}
                required
              />
              <User size={16} color="#64748b" style={{ position: 'absolute', right: '12px', top: '12px' }} />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <div style={{ position: 'relative' }}>
              <input
                type="password"
                className="form-input"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
              />
              <Lock size={16} color="#64748b" style={{ position: 'absolute', right: '12px', top: '12px' }} />
            </div>
          </div>

          <button type="submit" disabled={loading} className="btn btn-primary" style={{ width: '100%', marginTop: '1rem', padding: '0.8rem' }}>
            {loading ? 'Authenticating...' : 'Sign In to Dashboard'} <ArrowRight size={18} />
          </button>

          <div style={{ marginTop: '1.25rem', textAlign: 'center', fontSize: '0.85rem', color: '#94a3b8' }}>
            New Patient?{' '}
            <button type="button" onClick={onSwitchToRegister} style={{ background: 'none', color: '#22d3ee', fontWeight: 700 }}>
              Register Here
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
