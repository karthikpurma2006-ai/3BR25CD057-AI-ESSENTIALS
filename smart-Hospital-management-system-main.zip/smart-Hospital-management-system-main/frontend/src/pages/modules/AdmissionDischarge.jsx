import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { StatusBadge } from '../../components/StatusBadge';
import { UserCheck, Plus, LogOut, X } from 'lucide-react';

export const AdmissionDischarge = () => {
  const { addToast } = useNotification();
  const [admissions, setAdmissions] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [availableBeds, setAvailableBeds] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedAdmissionForDischarge, setSelectedAdmissionForDischarge] = useState(null);

  const [formData, setFormData] = useState({
    patient: '',
    doctor: '',
    bed: '',
    admission_reason: '',
    expected_discharge: '2026-09-10'
  });

  const [dischargeData, setDischargeData] = useState({
    discharge_summary: 'Discharged in stable condition. Instructed for follow-up in 10 days.',
    diagnosis_at_discharge: 'Resolved Acute Medical Condition'
  });

  const fetchAll = () => {
    api.get('admissions').then(setAdmissions).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
    api.get('doctors').then(setDoctors).catch(() => {});
    api.get('beds').then(data => setAvailableBeds(data.filter(b => b.status === 'AVAILABLE'))).catch(() => {});
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleAdmitPatient = async (e) => {
    e.preventDefault();
    try {
      const code = `ADM-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      await api.post('admissions', { ...formData, admission_id: code, status: 'ADMITTED' });
      addToast('Patient admitted and bed marked OCCUPIED successfully!', 'success');
      setShowModal(false);
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  const handleDischargePatient = async (e) => {
    e.preventDefault();
    if (!selectedAdmissionForDischarge) return;
    try {
      await api.customAction('admissions', selectedAdmissionForDischarge.id, 'discharge', dischargeData);
      addToast('Patient discharged successfully and bed marked AVAILABLE!', 'success');
      setSelectedAdmissionForDischarge(null);
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Inpatient Admissions & Discharges</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Admit patients into wards, assign beds, generate discharge summaries, and auto-update bed availability</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Admit Patient
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Admission Code</th>
                <th>Patient Name</th>
                <th>Assigned Doctor</th>
                <th>Ward & Bed</th>
                <th>Admission Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {admissions.map(adm => (
                <tr key={adm.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{adm.admission_id}</td>
                  <td style={{ fontWeight: 600 }}>{adm.patient_name}</td>
                  <td>{adm.doctor_name}</td>
                  <td><span className="badge badge-primary">{adm.bed_number || 'N/A'} ({adm.ward_name})</span></td>
                  <td>{new Date(adm.admission_date).toLocaleDateString()}</td>
                  <td><span className={`badge ${adm.status === 'ADMITTED' ? 'badge-danger' : 'badge-success'}`}>{adm.status}</span></td>
                  <td>
                    {adm.status === 'ADMITTED' && (
                      <button onClick={() => setSelectedAdmissionForDischarge(adm)} className="btn btn-danger btn-sm">
                        <LogOut size={14} /> Discharge Patient
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Inpatient Admission Form</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleAdmitPatient} className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Select Patient</label>
                <select className="form-select" value={formData.patient} onChange={e => setFormData({ ...formData, patient: e.target.value })} required>
                  <option value="">-- Choose Patient --</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.patient_id})</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Select Attending Doctor</label>
                <select className="form-select" value={formData.doctor} onChange={e => setFormData({ ...formData, doctor: e.target.value })} required>
                  <option value="">-- Choose Doctor --</option>
                  {doctors.map(d => <option key={d.id} value={d.id}>{d.doctor_name}</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Assign Available Bed</label>
                <select className="form-select" value={formData.bed} onChange={e => setFormData({ ...formData, bed: e.target.value })} required>
                  <option value="">-- Choose Available Bed --</option>
                  {availableBeds.map(b => <option key={b.id} value={b.id}>{b.bed_number} ({b.ward_name}) - ₹{b.daily_rate}/day</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Reason for Admission</label>
                <textarea className="form-textarea" rows="2" value={formData.admission_reason} onChange={e => setFormData({ ...formData, admission_reason: e.target.value })} required></textarea>
              </div>

              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-primary">Admit Patient</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Discharge Modal */}
      {selectedAdmissionForDischarge && (
        <div className="modal-overlay" onClick={() => setSelectedAdmissionForDischarge(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Discharge Patient ({selectedAdmissionForDischarge.admission_id})</h3>
              <button onClick={() => setSelectedAdmissionForDischarge(null)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleDischargePatient} className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Diagnosis at Discharge</label>
                <input type="text" className="form-input" value={dischargeData.diagnosis_at_discharge} onChange={e => setDischargeData({ ...dischargeData, diagnosis_at_discharge: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Discharge Summary & Follow-up Instructions</label>
                <textarea className="form-textarea" rows="3" value={dischargeData.discharge_summary} onChange={e => setDischargeData({ ...dischargeData, discharge_summary: e.target.value })} required></textarea>
              </div>

              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-danger">Confirm Discharge & Release Bed</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
