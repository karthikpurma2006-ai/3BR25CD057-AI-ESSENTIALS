import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { StatusBadge } from '../../components/StatusBadge';
import { BillInvoiceModal } from '../../components/BillInvoiceModal';
import { Plus, Receipt, DollarSign, Download, X } from 'lucide-react';

export const BillingPayment = () => {
  const { addToast } = useNotification();
  const [bills, setBills] = useState([]);
  const [patients, setPatients] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    patient: '',
    consultation_fee: 500.00,
    room_charges: 2000.00,
    lab_charges: 500.00,
    pharmacy_charges: 350.00,
    procedure_charges: 0.00,
    tax_amount: 150.00,
    discount: 100.00
  });

  const fetchBills = () => {
    api.get('bills').then(setBills).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
  };

  useEffect(() => {
    fetchBills();
  }, []);

  const handleCreateBill = async (e) => {
    e.preventDefault();
    try {
      const subtotal = 
        parseFloat(formData.consultation_fee) +
        parseFloat(formData.room_charges) +
        parseFloat(formData.lab_charges) +
        parseFloat(formData.pharmacy_charges) +
        parseFloat(formData.procedure_charges) +
        parseFloat(formData.tax_amount) -
        parseFloat(formData.discount);

      const billCode = `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      await api.post('bills', {
        ...formData,
        bill_code: billCode,
        total_amount: subtotal,
        paid_amount: 0,
        balance_amount: subtotal,
        status: 'PENDING'
      });

      addToast('Patient bill generated successfully!', 'success');
      setShowModal(false);
      fetchBills();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Billing & Payment Collection</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Generate itemized bills (consultation + bed + lab + pharmacy - discount), record payments, and export PDF invoices</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Generate New Bill
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Invoice Code</th>
                <th>Patient Name</th>
                <th>Total Charges</th>
                <th>Paid Amount</th>
                <th>Balance Due</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {bills.map(b => (
                <tr key={b.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{b.bill_code}</td>
                  <td style={{ fontWeight: 600 }}>{b.patient_name}</td>
                  <td style={{ fontWeight: 700 }}>₹{b.total_amount}</td>
                  <td style={{ color: '#34d399' }}>₹{b.paid_amount}</td>
                  <td style={{ color: '#f87171', fontWeight: 700 }}>₹{b.balance_amount}</td>
                  <td><StatusBadge status={b.status} /></td>
                  <td>
                    <button onClick={() => setSelectedBill(b)} className="btn btn-secondary btn-sm">
                      <Download size={14} /> View Invoice & Collect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Generate Itemized Hospital Bill</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleCreateBill} className="modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Select Patient</label>
                <select className="form-select" value={formData.patient} onChange={e => setFormData({ ...formData, patient: e.target.value })} required>
                  <option value="">-- Choose Patient --</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.patient_id})</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Consultation Fee (₹)</label>
                <input type="number" className="form-input" value={formData.consultation_fee} onChange={e => setFormData({ ...formData, consultation_fee: parseFloat(e.target.value) })} />
              </div>
              <div className="form-group">
                <label className="form-label">Room / Bed Charges (₹)</label>
                <input type="number" className="form-input" value={formData.room_charges} onChange={e => setFormData({ ...formData, room_charges: parseFloat(e.target.value) })} />
              </div>
              <div className="form-group">
                <label className="form-label">Lab Charges (₹)</label>
                <input type="number" className="form-input" value={formData.lab_charges} onChange={e => setFormData({ ...formData, lab_charges: parseFloat(e.target.value) })} />
              </div>
              <div className="form-group">
                <label className="form-label">Pharmacy Charges (₹)</label>
                <input type="number" className="form-input" value={formData.pharmacy_charges} onChange={e => setFormData({ ...formData, pharmacy_charges: parseFloat(e.target.value) })} />
              </div>
              <div className="form-group">
                <label className="form-label">Taxes (₹)</label>
                <input type="number" className="form-input" value={formData.tax_amount} onChange={e => setFormData({ ...formData, tax_amount: parseFloat(e.target.value) })} />
              </div>
              <div className="form-group">
                <label className="form-label">Discount (₹)</label>
                <input type="number" className="form-input" value={formData.discount} onChange={e => setFormData({ ...formData, discount: parseFloat(e.target.value) })} />
              </div>

              <div className="modal-footer" style={{ gridColumn: 'span 2', padding: 0 }}>
                <button type="submit" className="btn btn-primary">Generate Final Invoice</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selectedBill && (
        <BillInvoiceModal bill={selectedBill} onClose={() => setSelectedBill(null)} onRefresh={fetchBills} />
      )}
    </div>
  );
};
