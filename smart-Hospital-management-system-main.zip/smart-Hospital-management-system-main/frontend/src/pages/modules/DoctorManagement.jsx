import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { Plus, Search, Stethoscope, Edit, X } from 'lucide-react';

export const DoctorManagement = () => {
  const { addToast } = useNotification();
  const [doctors, setDoctors] = useState([]);
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    api.get('doctors').then(setDoctors).catch(() => {});
    api.get('departments').then(setDepartments).catch(() => {});
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Doctors Directory & Specializations</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Manage medical staff, consultation fees, schedules, and approvals</p>
        </div>
      </div>

      <div className="grid-3">
        {doctors.map(doc => (
          <div key={doc.id} className="glass-card interactive" style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div style={{ width: '54px', height: '54px', borderRadius: '50%', background: '#0891b2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '1.2rem', color: '#fff' }}>
                {doc.doctor_name?.[4] || 'D'}
              </div>
              <div>
                <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>{doc.doctor_name}</h3>
                <span className="badge badge-primary" style={{ fontSize: '0.7rem' }}>{doc.specialization}</span>
              </div>
            </div>

            <div style={{ fontSize: '0.85rem', color: '#94a3b8', display: 'flex', flexDirection: 'column', gap: '0.2rem', marginTop: '0.5rem' }}>
              <div><strong>Qualification:</strong> {doc.qualification}</div>
              <div><strong>Experience:</strong> {doc.experience_years} years</div>
              <div><strong>Department:</strong> {doc.department_name}</div>
              <div><strong>Consultation Fee:</strong> ₹{doc.consultation_fee}</div>
              <div><strong>Schedule:</strong> {doc.available_times}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
