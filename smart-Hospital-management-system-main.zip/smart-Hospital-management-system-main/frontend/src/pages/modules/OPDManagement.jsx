import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { Clock, Ticket, Plus, CheckCircle2, X } from 'lucide-react';

export const OPDManagement = () => {
  const { addToast } = useNotification();
  const [tokens, setTokens] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    patient: '',
    doctor: '',
    consultation_fee: 500.00
  });

  const fetchAll = () => {
    api.get('opd-tokens').then(setTokens).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
    api.get('doctors').then(setDoctors).catch(() => {});
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleIssueToken = async (e) => {
    e.preventDefault();
    try {
      const nextTokenNum = tokens.length + 1;
      const code = `OPD-2026-${Math.floor(100 + Math.random() * 900)}`;
      await api.post('opd-tokens', {
        ...formData,
        token_number: nextTokenNum,
        token_code: code,
        status: 'WAITING'
      });
      addToast(`OPD Token #${nextTokenNum} issued successfully!`, 'success');
      setShowModal(false);
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  const handleStatusChange = async (tokenId, newStatus) => {
    try {
      await api.put('opd-tokens', tokenId, { status: newStatus });
      addToast(`OPD Token status updated to ${newStatus}`, 'info');
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Outpatient Department (OPD) Tokens</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Generate live token numbers, manage patient waiting queues, and record OPD consultation status</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Ticket size={18} /> Issue OPD Token
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Token #</th>
                <th>Token Code</th>
                <th>Patient Name</th>
                <th>Assigned Doctor</th>
                <th>Fee</th>
                <th>Queue Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {tokens.map(tok => (
                <tr key={tok.id}>
                  <td style={{ fontWeight: 800, fontSize: '1.1rem', color: '#22d3ee' }}>#{tok.token_number}</td>
                  <td>{tok.token_code}</td>
                  <td style={{ fontWeight: 600 }}>{tok.patient_name}</td>
                  <td>{tok.doctor_name}</td>
                  <td>₹{tok.consultation_fee}</td>
                  <td>
                    <span className={`badge ${
                      tok.status === 'WAITING' ? 'badge-warning' :
                      tok.status === 'IN_CONSULTATION' ? 'badge-primary' : 'badge-success'
                    }`}>{tok.status}</span>
                  </td>
                  <td style={{ display: 'flex', gap: '0.4rem' }}>
                    {tok.status === 'WAITING' && (
                      <button onClick={() => handleStatusChange(tok.id, 'IN_CONSULTATION')} className="btn btn-primary btn-sm">
                        Call Patient
                      </button>
                    )}
                    {tok.status === 'IN_CONSULTATION' && (
                      <button onClick={() => handleStatusChange(tok.id, 'COMPLETED')} className="btn btn-success btn-sm">
                        Complete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Issue New OPD Consultation Token</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleIssueToken} className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Select Patient</label>
                <select className="form-select" value={formData.patient} onChange={e => setFormData({ ...formData, patient: e.target.value })} required>
                  <option value="">-- Select Patient --</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.patient_id})</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Select Doctor</label>
                <select className="form-select" value={formData.doctor} onChange={e => {
                  const doc = doctors.find(d => String(d.id) === String(e.target.value));
                  setFormData({ ...formData, doctor: e.target.value, consultation_fee: doc?.consultation_fee || 500 });
                }} required>
                  <option value="">-- Select Doctor --</option>
                  {doctors.map(d => <option key={d.id} value={d.id}>{d.doctor_name} ({d.specialization})</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Consultation Fee (₹)</label>
                <input type="number" className="form-input" value={formData.consultation_fee} readOnly />
              </div>

              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-primary">Issue Token</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
