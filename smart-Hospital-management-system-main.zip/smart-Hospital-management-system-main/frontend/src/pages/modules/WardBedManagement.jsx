import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { BedGrid } from '../../components/BedGrid';
import { BedDouble, Plus, X } from 'lucide-react';

export const WardBedManagement = () => {
  const { addToast } = useNotification();
  const [wards, setWards] = useState([]);
  const [beds, setBeds] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    ward: '',
    bed_number: 'BED-105',
    daily_rate: 1000.00
  });

  const fetchAll = () => {
    api.get('wards').then(setWards).catch(() => {});
    api.get('beds').then(setBeds).catch(() => {});
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleAddBed = async (e) => {
    e.preventDefault();
    try {
      await api.post('beds', { ...formData, status: 'AVAILABLE' });
      addToast('New Bed added to ward successfully!', 'success');
      setShowModal(false);
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Ward & Bed Management</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Real-time visual bed status tracking for General, ICU, Emergency, and Private rooms</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Add New Bed
        </button>
      </div>

      <BedGrid wards={wards} beds={beds} />

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Add Bed to Ward</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleAddBed} className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Select Ward</label>
                <select className="form-select" value={formData.ward} onChange={e => setFormData({ ...formData, ward: e.target.value })} required>
                  <option value="">-- Choose Ward --</option>
                  {wards.map(w => <option key={w.id} value={w.id}>{w.name} ({w.ward_type})</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Bed Number / Identifier</label>
                <input type="text" className="form-input" placeholder="e.g. BED-109" value={formData.bed_number} onChange={e => setFormData({ ...formData, bed_number: e.target.value })} required />
              </div>

              <div className="form-group">
                <label className="form-label">Daily Charge Rate (₹)</label>
                <input type="number" step="0.01" className="form-input" value={formData.daily_rate} onChange={e => setFormData({ ...formData, daily_rate: parseFloat(e.target.value) })} required />
              </div>

              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-primary">Save Bed</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
