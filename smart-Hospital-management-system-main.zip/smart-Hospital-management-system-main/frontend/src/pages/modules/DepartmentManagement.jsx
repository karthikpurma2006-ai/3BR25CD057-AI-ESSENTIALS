import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { Building2, Plus, Stethoscope, X } from 'lucide-react';

export const DepartmentManagement = () => {
  const { addToast } = useNotification();
  const [departments, setDepartments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ name: '', code: '', description: '' });

  const fetchDepts = () => {
    api.get('departments').then(setDepartments).catch(() => {});
  };

  useEffect(() => {
    fetchDepts();
  }, []);

  const handleAddDept = async (e) => {
    e.preventDefault();
    try {
      await api.post('departments', formData);
      addToast('Department added successfully!', 'success');
      setShowModal(false);
      fetchDepts();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Hospital Departments</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Organize clinical units, specialty centers, and doctors assignment</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Add Department
        </button>
      </div>

      <div className="grid-3">
        {departments.map(dept => (
          <div key={dept.id} className="glass-card interactive">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
              <div style={{ width: '42px', height: '42px', borderRadius: '10px', background: 'rgba(8,145,178,0.2)', border: '1px solid rgba(8,145,178,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Building2 size={22} color="#22d3ee" />
              </div>
              <div>
                <h3 style={{ fontSize: '1.15rem', color: '#fff' }}>{dept.name}</h3>
                <span className="badge badge-primary">{dept.code}</span>
              </div>
            </div>
            <p style={{ fontSize: '0.85rem', color: '#94a3b8', lineHeight: 1.5 }}>{dept.description}</p>
            <div style={{ marginTop: '1rem', paddingTop: '0.75rem', borderTop: '1px solid rgba(255,255,255,0.08)', fontSize: '0.8rem', color: '#64748b', display: 'flex', justifyContent: 'space-between' }}>
              <span>Assigned Doctors:</span>
              <strong style={{ color: '#34d399' }}>{dept.doctor_count || 2} Specialists</strong>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Create New Department</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleAddDept} className="modal-body">
              <div className="form-group">
                <label className="form-label">Department Name</label>
                <input type="text" className="form-input" placeholder="e.g. Dermatology" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Department Code</label>
                <input type="text" className="form-input" placeholder="e.g. DERM" value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea className="form-textarea" rows="3" value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })}></textarea>
              </div>
              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-primary">Save Department</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
