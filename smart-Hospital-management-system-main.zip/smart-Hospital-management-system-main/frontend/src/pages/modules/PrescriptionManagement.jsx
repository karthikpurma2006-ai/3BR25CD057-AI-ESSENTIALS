import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { PrescriptionModal } from '../../components/PrescriptionModal';
import { Plus, HeartPulse, Download, Trash2, X } from 'lucide-react';

export const PrescriptionManagement = () => {
  const { addToast } = useNotification();
  const [prescriptions, setPrescriptions] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [selectedRx, setSelectedRx] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    patient: '',
    doctor: '',
    diagnosis: '',
    items: [
      { medicine_name: '', dosage: '500 mg', frequency: '2 times/day', duration: '5 days', instructions: 'After meal' }
    ]
  });

  const fetchAll = () => {
    api.get('prescriptions').then(setPrescriptions).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
    api.get('doctors').then(setDoctors).catch(() => {});
    api.get('medicines').then(setMedicines).catch(() => {});
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleAddItem = () => {
    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { medicine_name: '', dosage: '500 mg', frequency: '2 times/day', duration: '5 days', instructions: 'After meal' }]
    }));
  };

  const handleItemChange = (index, field, val) => {
    const newItems = [...formData.items];
    newItems[index][field] = val;
    setFormData({ ...formData, items: newItems });
  };

  const handleSaveRx = async (e) => {
    e.preventDefault();
    try {
      const rxCode = `RX-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      await api.post('prescriptions', { ...formData, prescription_code: rxCode });
      addToast('Prescription generated and saved!', 'success');
      setShowModal(false);
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Prescription Management</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Create digital prescriptions with itemized dosages and export to PDF</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Create Prescription
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Rx Code</th>
                <th>Patient</th>
                <th>Prescribed By</th>
                <th>Diagnosis</th>
                <th>Medicines</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {prescriptions.map(rx => (
                <tr key={rx.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{rx.prescription_code}</td>
                  <td style={{ fontWeight: 600 }}>{rx.patient_name}</td>
                  <td>{rx.doctor_name}</td>
                  <td>{rx.diagnosis}</td>
                  <td>{rx.items?.length || 0} prescribed</td>
                  <td><span className="badge badge-success">{rx.status}</span></td>
                  <td>
                    <button onClick={() => setSelectedRx(rx)} className="btn btn-secondary btn-sm">
                      <Download size={14} /> PDF
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Prescription Builder Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '720px' }}>
            <div className="modal-header">
              <h3>Create Digital Prescription</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSaveRx} className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="form-group">
                  <label className="form-label">Select Patient</label>
                  <select className="form-select" value={formData.patient} onChange={e => setFormData({ ...formData, patient: e.target.value })} required>
                    <option value="">-- Select Patient --</option>
                    {patients.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.patient_id})</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Select Doctor</label>
                  <select className="form-select" value={formData.doctor} onChange={e => setFormData({ ...formData, doctor: e.target.value })} required>
                    <option value="">-- Select Doctor --</option>
                    {doctors.map(d => <option key={d.id} value={d.id}>{d.doctor_name}</option>)}
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Diagnosis</label>
                <input type="text" className="form-input" placeholder="e.g. Essential Mild Hypertension" value={formData.diagnosis} onChange={e => setFormData({ ...formData, diagnosis: e.target.value })} required />
              </div>

              {/* Medicine Item Inputs */}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                  <h4 style={{ fontSize: '0.9rem', color: '#fff' }}>Prescribed Medications</h4>
                  <button type="button" onClick={handleAddItem} className="btn btn-secondary btn-sm">+ Add Medicine</button>
                </div>

                {formData.items.map((item, idx) => (
                  <div key={idx} style={{ background: 'rgba(15,23,42,0.8)', padding: '0.75rem', borderRadius: '8px', marginBottom: '0.5rem', display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: '0.5rem' }}>
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Medicine Name (e.g. Paracetamol 650mg)"
                      value={item.medicine_name}
                      onChange={e => handleItemChange(idx, 'medicine_name', e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Dosage (500mg)"
                      value={item.dosage}
                      onChange={e => handleItemChange(idx, 'dosage', e.target.value)}
                    />
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Freq (2x/day)"
                      value={item.frequency}
                      onChange={e => handleItemChange(idx, 'frequency', e.target.value)}
                    />
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Duration (5 days)"
                      value={item.duration}
                      onChange={e => handleItemChange(idx, 'duration', e.target.value)}
                    />
                  </div>
                ))}
              </div>

              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-primary">Save & Issue Prescription</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selectedRx && (
        <PrescriptionModal prescription={selectedRx} onClose={() => setSelectedRx(null)} />
      )}
    </div>
  );
};
