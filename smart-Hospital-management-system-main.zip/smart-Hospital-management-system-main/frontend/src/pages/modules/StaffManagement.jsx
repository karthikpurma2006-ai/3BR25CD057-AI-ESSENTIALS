import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Shield, Plus } from 'lucide-react';

export const StaffManagement = () => {
  const [staff, setStaff] = useState([]);

  useEffect(() => {
    api.get('staff').then(setStaff).catch(() => {});
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Staff & Employee Directory</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Manage hospital nurses, receptionists, pharmacists, lab techs, and accountants</p>
        </div>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Emp ID</th>
                <th>Staff Name</th>
                <th>Role</th>
                <th>Department</th>
                <th>Qualification</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {staff.map(s => (
                <tr key={s.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{s.employee_id}</td>
                  <td style={{ fontWeight: 600 }}>{s.user?.first_name ? `${s.user.first_name} ${s.user.last_name}` : s.user?.username}</td>
                  <td><span className="badge badge-primary">{s.role}</span></td>
                  <td>{s.department_name || 'Central'}</td>
                  <td>{s.qualification || 'Certified'}</td>
                  <td><span className="badge badge-success">{s.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
