import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { StatusBadge } from '../../components/StatusBadge';
import { AlertTriangle, Plus, ShieldAlert, X } from 'lucide-react';

export const EmergencyManagement = () => {
  const { addToast } = useNotification();
  const [emergencies, setEmergencies] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    patient_name: '',
    age: 35,
    gender: 'Male',
    contact: '',
    priority: 'CRITICAL',
    assigned_doctor: '',
    treatment_notes: 'Immediate trauma triage and oxygen resuscitation'
  });

  const fetchAll = () => {
    api.get('emergencies').then(setEmergencies).catch(() => {});
    api.get('doctors').then(setDoctors).catch(() => {});
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleRegisterEmergency = async (e) => {
    e.preventDefault();
    try {
      const code = `EMG-2026-${Math.floor(100 + Math.random() * 900)}`;
      await api.post('emergencies', { ...formData, case_id: code, status: 'ACTIVE' });
      addToast('Emergency case registered & priority team alerted!', 'success');
      setShowModal(false);
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#f87171', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <AlertTriangle size={24} color="#f87171" /> 24/7 Emergency & Triage Unit
          </h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Register critical emergency cases, assign priority levels (Critical, High, Medium, Low), and triage doctors</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-danger">
          <Plus size={18} /> Register Emergency Case
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden', border: '1px solid rgba(220,38,38,0.3)' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Case ID</th>
                <th>Patient Name</th>
                <th>Age / Gender</th>
                <th>Contact</th>
                <th>Priority Triage</th>
                <th>Assigned Doctor</th>
                <th>Treatment Notes</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {emergencies.map(emg => (
                <tr key={emg.id}>
                  <td style={{ fontWeight: 800, color: '#f87171' }}>{emg.case_id}</td>
                  <td style={{ fontWeight: 700, color: '#fff' }}>{emg.patient_name}</td>
                  <td>{emg.age} y / {emg.gender}</td>
                  <td>{emg.contact}</td>
                  <td><StatusBadge status={emg.priority} /></td>
                  <td>{emg.doctor_name}</td>
                  <td style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>{emg.treatment_notes}</td>
                  <td><span className="badge badge-danger">{emg.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3 style={{ color: '#f87171' }}>Register Emergency Triage Patient</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleRegisterEmergency} className="modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Emergency Patient Name</label>
                <input type="text" className="form-input" value={formData.patient_name} onChange={e => setFormData({ ...formData, patient_name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Age</label>
                <input type="number" className="form-input" value={formData.age} onChange={e => setFormData({ ...formData, age: parseInt(e.target.value) })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Priority Triage Level</label>
                <select className="form-select" value={formData.priority} onChange={e => setFormData({ ...formData, priority: e.target.value })}>
                  <option value="CRITICAL">Critical (Immediate Code Red)</option>
                  <option value="HIGH">High Priority</option>
                  <option value="MEDIUM">Medium Priority</option>
                  <option value="LOW">Low Priority</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Contact Number</label>
                <input type="text" className="form-input" value={formData.contact} onChange={e => setFormData({ ...formData, contact: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Assign Emergency Doctor</label>
                <select className="form-select" value={formData.assigned_doctor} onChange={e => setFormData({ ...formData, assigned_doctor: e.target.value })}>
                  <option value="">-- Unassigned / On-Call Doctor --</option>
                  {doctors.map(d => <option key={d.id} value={d.id}>{d.doctor_name}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Immediate Triage Notes</label>
                <textarea className="form-textarea" rows="2" value={formData.treatment_notes} onChange={e => setFormData({ ...formData, treatment_notes: e.target.value })}></textarea>
              </div>
              <div className="modal-footer" style={{ gridColumn: 'span 2', padding: 0 }}>
                <button type="submit" className="btn btn-danger">Trigger Emergency Alert</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
