import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { Plus, Pill, AlertTriangle, Search, X } from 'lucide-react';

export const PharmacyManagement = () => {
  const { addToast } = useNotification();
  const [medicines, setMedicines] = useState([]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    category: 'Analgesic',
    manufacturer: 'Cipla Ltd',
    batch_number: 'BATCH-2026-X',
    quantity: 100,
    min_threshold: 20,
    price: 50.00,
    expiry_date: '2027-12-31',
    supplier: 'National Distributors'
  });

  const fetchMedicines = () => {
    api.get('medicines').then(setMedicines).catch(() => {});
  };

  useEffect(() => {
    fetchMedicines();
  }, []);

  const handleAddMedicine = async (e) => {
    e.preventDefault();
    try {
      const code = `MED-${Math.floor(100 + Math.random() * 900)}`;
      await api.post('medicines', { ...formData, medicine_code: code });
      addToast('Medicine added to inventory successfully!', 'success');
      setShowModal(false);
      fetchMedicines();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  const filtered = medicines.filter(m => m.name?.toLowerCase().includes(search.toLowerCase()) || m.category?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Pharmacy & Medication Inventory</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Monitor drug stocks, low-stock thresholds, batch numbers, and expiry alerts</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Add Medicine Stock
        </button>
      </div>

      <div className="glass-card" style={{ padding: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', background: 'rgba(15,23,42,0.8)', padding: '0.65rem 1rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.08)' }}>
          <Search size={18} color="#0891b2" />
          <input
            type="text"
            placeholder="Search medicine by name or category..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ background: 'none', border: 'none', outline: 'none', color: '#fff', width: '100%', fontSize: '0.9rem' }}
          />
        </div>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Medicine Name</th>
                <th>Category</th>
                <th>Batch #</th>
                <th>Quantity in Stock</th>
                <th>Unit Price</th>
                <th>Expiry Date</th>
                <th>Stock Alert</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(m => (
                <tr key={m.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{m.medicine_code}</td>
                  <td style={{ fontWeight: 600 }}>{m.name}</td>
                  <td><span className="badge badge-secondary">{m.category}</span></td>
                  <td>{m.batch_number}</td>
                  <td style={{ fontWeight: 700, color: m.is_low_stock ? '#f87171' : '#34d399' }}>{m.quantity} units</td>
                  <td>₹{m.price}</td>
                  <td>{m.expiry_date}</td>
                  <td>
                    {m.is_low_stock ? (
                      <span className="badge badge-danger">Low Stock Alert</span>
                    ) : (
                      <span className="badge badge-success">In Stock</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Add Medicine to Pharmacy Inventory</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleAddMedicine} className="modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Medicine Name</label>
                <input type="text" className="form-input" placeholder="e.g. Paracetamol 650mg" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Category</label>
                <input type="text" className="form-input" value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Manufacturer</label>
                <input type="text" className="form-input" value={formData.manufacturer} onChange={e => setFormData({ ...formData, manufacturer: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Quantity</label>
                <input type="number" className="form-input" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: parseInt(e.target.value) })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Price (₹)</label>
                <input type="number" step="0.01" className="form-input" value={formData.price} onChange={e => setFormData({ ...formData, price: parseFloat(e.target.value) })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Min Threshold Alert</label>
                <input type="number" className="form-input" value={formData.min_threshold} onChange={e => setFormData({ ...formData, min_threshold: parseInt(e.target.value) })} />
              </div>
              <div className="form-group">
                <label className="form-label">Expiry Date</label>
                <input type="date" className="form-input" value={formData.expiry_date} onChange={e => setFormData({ ...formData, expiry_date: e.target.value })} required />
              </div>
              <div className="modal-footer" style={{ gridColumn: 'span 2', padding: 0 }}>
                <button type="submit" className="btn btn-primary">Add Medicine</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
