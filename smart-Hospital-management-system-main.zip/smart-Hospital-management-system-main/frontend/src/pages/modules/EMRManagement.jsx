import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { Plus, FileText, Activity, Stethoscope, User, X } from 'lucide-react';

export const EMRManagement = () => {
  const { addToast } = useNotification();
  const [emrRecords, setEmrRecords] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    patient: '',
    doctor: '',
    visit_date: new Date().toISOString().split('T')[0],
    symptoms: '',
    diagnosis: '',
    treatment_plan: '',
    doctor_notes: '',
    vital_bp: '120/80',
    vital_temp: '98.6',
    vital_hr: '72',
    vital_spo2: '98'
  });

  const fetchRecords = () => {
    api.get('emr').then(setEmrRecords).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
    api.get('doctors').then(setDoctors).catch(() => {});
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  const handleSaveEMR = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        patient: formData.patient,
        doctor: formData.doctor,
        visit_date: formData.visit_date,
        symptoms: formData.symptoms,
        diagnosis: formData.diagnosis,
        treatment_plan: formData.treatment_plan,
        doctor_notes: formData.doctor_notes,
        vital_signs: {
          bp: `${formData.vital_bp} mmHg`,
          temp: `${formData.vital_temp} °F`,
          pulse: `${formData.vital_hr} bpm`,
          spo2: `${formData.vital_spo2}%`
        }
      };
      await api.post('emr', payload);
      addToast('EMR Clinical Record saved successfully!', 'success');
      setShowModal(false);
      fetchRecords();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Electronic Medical Records (EMR)</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Comprehensive patient history, vitals, symptoms, diagnosis, and treatment plans</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> New Clinical EMR Entry
        </button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {emrRecords.map(rec => (
          <div key={rec.id} className="glass-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.85rem', borderBottom: '1px solid rgba(255,255,255,0.08)', paddingBottom: '0.65rem' }}>
              <div>
                <h3 style={{ fontSize: '1.1rem', color: '#fff' }}>Patient: {rec.patient_name}</h3>
                <span style={{ fontSize: '0.8rem', color: '#0891b2', fontWeight: 600 }}>Attending: {rec.doctor_name} • Visit Date: {rec.visit_date}</span>
              </div>
              <span className="badge badge-success">EMR Verified</span>
            </div>

            <div className="grid-3" style={{ marginBottom: '0.85rem' }}>
              <div style={{ background: 'rgba(15,23,42,0.8)', padding: '0.75rem', borderRadius: '8px' }}>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700 }}>Symptoms Reported</span>
                <p style={{ fontSize: '0.9rem', color: '#fff', marginTop: '0.2rem' }}>{rec.symptoms}</p>
              </div>
              <div style={{ background: 'rgba(15,23,42,0.8)', padding: '0.75rem', borderRadius: '8px' }}>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700 }}>Clinical Diagnosis</span>
                <p style={{ fontSize: '0.9rem', color: '#22d3ee', fontWeight: 700, marginTop: '0.2rem' }}>{rec.diagnosis}</p>
              </div>
              <div style={{ background: 'rgba(15,23,42,0.8)', padding: '0.75rem', borderRadius: '8px' }}>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700 }}>Recorded Vital Signs</span>
                <div style={{ fontSize: '0.85rem', color: '#fff', marginTop: '0.2rem' }}>
                  BP: {rec.vital_signs?.bp || '120/80'} • Temp: {rec.vital_signs?.temp || '98.6F'} • SpO2: {rec.vital_signs?.spo2 || '98%'}
                </div>
              </div>
            </div>

            {rec.treatment_plan && (
              <div style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>
                <strong>Treatment Plan:</strong> {rec.treatment_plan}
              </div>
            )}
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '680px' }}>
            <div className="modal-header">
              <h3>Create Clinical EMR Record</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSaveEMR} className="modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Select Patient</label>
                <select className="form-select" value={formData.patient} onChange={e => setFormData({ ...formData, patient: e.target.value })} required>
                  <option value="">-- Choose Patient --</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.patient_id})</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Select Attending Doctor</label>
                <select className="form-select" value={formData.doctor} onChange={e => setFormData({ ...formData, doctor: e.target.value })} required>
                  <option value="">-- Choose Doctor --</option>
                  {doctors.map(d => <option key={d.id} value={d.id}>{d.doctor_name}</option>)}
                </select>
              </div>

              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Symptoms</label>
                <input type="text" className="form-input" placeholder="e.g. Fever, chest pain, nausea" value={formData.symptoms} onChange={e => setFormData({ ...formData, symptoms: e.target.value })} required />
              </div>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Clinical Diagnosis</label>
                <input type="text" className="form-input" placeholder="e.g. Acute Bronchitis" value={formData.diagnosis} onChange={e => setFormData({ ...formData, diagnosis: e.target.value })} required />
              </div>

              {/* Vitals */}
              <div className="form-group">
                <label className="form-label">Blood Pressure (mmHg)</label>
                <input type="text" className="form-input" value={formData.vital_bp} onChange={e => setFormData({ ...formData, vital_bp: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Temperature (°F)</label>
                <input type="text" className="form-input" value={formData.vital_temp} onChange={e => setFormData({ ...formData, vital_temp: e.target.value })} />
              </div>

              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Treatment Plan & Doctor Notes</label>
                <textarea className="form-textarea" rows="3" value={formData.treatment_plan} onChange={e => setFormData({ ...formData, treatment_plan: e.target.value })}></textarea>
              </div>

              <div className="modal-footer" style={{ gridColumn: 'span 2', padding: 0 }}>
                <button type="submit" className="btn btn-primary">Save EMR Entry</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
