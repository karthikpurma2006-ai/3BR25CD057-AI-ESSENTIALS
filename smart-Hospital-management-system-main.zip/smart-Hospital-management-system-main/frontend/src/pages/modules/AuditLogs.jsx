import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Shield } from 'lucide-react';

export const AuditLogs = () => {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    api.get('audit-logs').then(setLogs).catch(() => {});
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>System Security & Audit Trail</h2>
        <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Comprehensive activity logging of actions, modules, timestamps, and user roles for compliance</p>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Role</th>
                <th>Action Recorded</th>
                <th>Module</th>
                <th>IP Address</th>
              </tr>
            </thead>
            <tbody>
              {logs.map(log => (
                <tr key={log.id}>
                  <td style={{ color: '#94a3b8', fontSize: '0.8rem' }}>{new Date(log.timestamp).toLocaleString()}</td>
                  <td><span className="badge badge-primary">{log.user_role}</span></td>
                  <td style={{ fontWeight: 600, color: '#fff' }}>{log.action}</td>
                  <td>{log.module}</td>
                  <td style={{ fontSize: '0.8rem', color: '#64748b' }}>{log.ip_address}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
