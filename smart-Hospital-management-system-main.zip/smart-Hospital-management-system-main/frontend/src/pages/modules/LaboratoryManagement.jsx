import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { StatusBadge } from '../../components/StatusBadge';
import { FlaskConical, Plus, Edit, X } from 'lucide-react';

export const LaboratoryManagement = () => {
  const { addToast } = useNotification();
  const [reports, setReports] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [labTests, setLabTests] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    patient: '',
    doctor: '',
    lab_test: '',
    sample_details: 'Venous blood sample'
  });

  const fetchAll = () => {
    api.get('lab-reports').then(setReports).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
    api.get('doctors').then(setDoctors).catch(() => {});
    api.get('lab-tests').then(setLabTests).catch(() => {});
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleRequestTest = async (e) => {
    e.preventDefault();
    try {
      const code = `LRP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      await api.post('lab-reports', { ...formData, report_code: code, status: 'REQUESTED' });
      addToast('Lab Test requested successfully!', 'success');
      setShowModal(false);
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  const handleStatusUpdate = async (reportId, newStatus) => {
    try {
      await api.put('lab-reports', reportId, {
        status: newStatus,
        results_summary: newStatus === 'COMPLETED' ? 'Test completed with normal findings. Parameters within expected reference range.' : ''
      });
      addToast(`Lab Report status updated to ${newStatus}`, 'info');
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Laboratory Diagnostics</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Order lab tests, update sample status (Requested → Collected → Processing → Completed), and publish diagnostic reports</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Request Lab Test
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Report Code</th>
                <th>Patient Name</th>
                <th>Test Name</th>
                <th>Ordering Doctor</th>
                <th>Sample Info</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {reports.map(rep => (
                <tr key={rep.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{rep.report_code}</td>
                  <td style={{ fontWeight: 600 }}>{rep.patient_name}</td>
                  <td style={{ fontWeight: 600, color: '#fff' }}>{rep.test_name}</td>
                  <td>{rep.doctor_name}</td>
                  <td>{rep.sample_details || 'N/A'}</td>
                  <td><StatusBadge status={rep.status} /></td>
                  <td style={{ display: 'flex', gap: '0.4rem' }}>
                    {rep.status === 'REQUESTED' && (
                      <button onClick={() => handleStatusUpdate(rep.id, 'SAMPLE_COLLECTED')} className="btn btn-secondary btn-sm">
                        Collect Sample
                      </button>
                    )}
                    {rep.status === 'SAMPLE_COLLECTED' && (
                      <button onClick={() => handleStatusUpdate(rep.id, 'PROCESSING')} className="btn btn-warning btn-sm">
                        Process Test
                      </button>
                    )}
                    {rep.status === 'PROCESSING' && (
                      <button onClick={() => handleStatusUpdate(rep.id, 'COMPLETED')} className="btn btn-success btn-sm">
                        Upload Results
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Order New Laboratory Test</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleRequestTest} className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Select Patient</label>
                <select className="form-select" value={formData.patient} onChange={e => setFormData({ ...formData, patient: e.target.value })} required>
                  <option value="">-- Choose Patient --</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.patient_id})</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Ordering Doctor</label>
                <select className="form-select" value={formData.doctor} onChange={e => setFormData({ ...formData, doctor: e.target.value })} required>
                  <option value="">-- Choose Doctor --</option>
                  {doctors.map(d => <option key={d.id} value={d.id}>{d.doctor_name}</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Lab Test Catalog Item</label>
                <select className="form-select" value={formData.lab_test} onChange={e => setFormData({ ...formData, lab_test: e.target.value })} required>
                  <option value="">-- Choose Lab Test --</option>
                  {labTests.map(t => <option key={t.id} value={t.id}>{t.name} ({t.category}) - ₹{t.cost}</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Sample Details / Notes</label>
                <input type="text" className="form-input" value={formData.sample_details} onChange={e => setFormData({ ...formData, sample_details: e.target.value })} />
              </div>

              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-primary">Request Test</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
