import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { Package, Plus, AlertTriangle, X } from 'lucide-react';

export const InventoryManagement = () => {
  const { addToast } = useNotification();
  const [items, setItems] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    category: 'Consumable',
    quantity: 100,
    unit: 'pcs',
    reorder_level: 20,
    supplier: 'MedTech Supplies'
  });

  const fetchItems = () => {
    api.get('inventory').then(setItems).catch(() => {});
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleAddItem = async (e) => {
    e.preventDefault();
    try {
      const code = `INV-${Math.floor(100 + Math.random() * 900)}`;
      await api.post('inventory', { ...formData, item_code: code });
      addToast('Inventory item added successfully!', 'success');
      setShowModal(false);
      fetchItems();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Hospital Inventory & Supplies</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Manage medical equipment, gloves, masks, syringes, and consumables stock</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Add Inventory Item
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Item Code</th>
                <th>Item Name</th>
                <th>Category</th>
                <th>Quantity in Stock</th>
                <th>Reorder Level</th>
                <th>Supplier</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <tr key={item.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{item.item_code}</td>
                  <td style={{ fontWeight: 600 }}>{item.name}</td>
                  <td><span className="badge badge-secondary">{item.category}</span></td>
                  <td style={{ fontWeight: 700, color: item.is_low_stock ? '#f87171' : '#34d399' }}>{item.quantity} {item.unit}</td>
                  <td>{item.reorder_level} {item.unit}</td>
                  <td>{item.supplier}</td>
                  <td>
                    {item.is_low_stock ? (
                      <span className="badge badge-danger">Reorder Required</span>
                    ) : (
                      <span className="badge badge-success">Sufficient</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Add Hospital Supply Item</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleAddItem} className="modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Supply Item Name</label>
                <input type="text" className="form-input" placeholder="e.g. Surgical Gloves (M)" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Category</label>
                <select className="form-select" value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })}>
                  <option value="Consumable">Consumable</option>
                  <option value="Equipment">Medical Equipment</option>
                  <option value="Protective">Protective Gear</option>
                  <option value="Surgical">Surgical Supply</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Quantity</label>
                <input type="number" className="form-input" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: parseInt(e.target.value) })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Unit (pcs/boxes)</label>
                <input type="text" className="form-input" value={formData.unit} onChange={e => setFormData({ ...formData, unit: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Reorder Level Threshold</label>
                <input type="number" className="form-input" value={formData.reorder_level} onChange={e => setFormData({ ...formData, reorder_level: parseInt(e.target.value) })} />
              </div>
              <div className="modal-footer" style={{ gridColumn: 'span 2', padding: 0 }}>
                <button type="submit" className="btn btn-primary">Save Item</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
