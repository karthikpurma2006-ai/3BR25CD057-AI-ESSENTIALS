import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Download, Sparkles, FileSpreadsheet } from 'lucide-react';
import html2pdf from 'html2pdf.js';

export const ReportsAnalytics = () => {
  const [bills, setBills] = useState([]);
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    api.get('bills').then(setBills).catch(() => {});
    api.get('appointments').then(setAppointments).catch(() => {});
  }, []);

  const downloadPDF = () => {
    const element = document.getElementById('report-export-area');
    const opt = {
      margin: 0.5,
      filename: `Sanjeevini_Hospital_Report_2026.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
  };

  const downloadCSV = () => {
    let csv = 'Bill Code,Patient,Total Amount,Paid Amount,Balance,Status\n';
    bills.forEach(b => {
      csv += `"${b.bill_code}","${b.patient_name}",${b.total_amount},${b.paid_amount},${b.balance_amount},"${b.status}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Sanjeevini_Financial_Report.csv';
    a.click();
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Hospital Analytics & Export Reports</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Generate operational metrics, financial summaries, and export data to PDF / CSV format</p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button onClick={downloadCSV} className="btn btn-secondary">
            <FileSpreadsheet size={18} /> Export CSV
          </button>
          <button onClick={downloadPDF} className="btn btn-primary">
            <Download size={18} /> Export PDF Report
          </button>
        </div>
      </div>

      <div id="report-export-area" className="glass-card">
        <h3 style={{ fontSize: '1.2rem', marginBottom: '1rem', color: '#fff' }}>Sanjeevini Multispeciality Executive Summary Report</h3>
        <p style={{ color: '#94a3b8', fontSize: '0.85rem', marginBottom: '1.5rem' }}>
          Generated on {new Date().toLocaleDateString()} for Hospital Administration Viva Presentation
        </p>

        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Invoice Code</th>
                <th>Patient</th>
                <th>Total Charges</th>
                <th>Paid Amount</th>
                <th>Balance Due</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {bills.map(b => (
                <tr key={b.id}>
                  <td style={{ fontWeight: 700, color: '#22d3ee' }}>{b.bill_code}</td>
                  <td>{b.patient_name}</td>
                  <td>₹{b.total_amount}</td>
                  <td style={{ color: '#34d399' }}>₹{b.paid_amount}</td>
                  <td style={{ color: '#f87171' }}>₹{b.balance_amount}</td>
                  <td><span className={`badge ${b.status === 'PAID' ? 'badge-success' : 'badge-warning'}`}>{b.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
