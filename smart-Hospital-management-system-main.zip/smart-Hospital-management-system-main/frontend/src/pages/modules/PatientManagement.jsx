import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { Plus, Search, User, Edit, Eye, Trash2, X } from 'lucide-react';

export const PatientManagement = () => {
  const { addToast } = useNotification();
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);
  
  const [formData, setFormData] = useState({
    full_name: '',
    dob: '1992-06-15',
    gender: 'Male',
    blood_group: 'O+',
    phone: '',
    email: '',
    address: '',
    emergency_contact: '',
    medical_history: '',
    allergies: ''
  });

  const fetchPatients = () => {
    api.get('patients').then(setPatients).catch(() => {});
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const handleSavePatient = async (e) => {
    e.preventDefault();
    try {
      if (selectedPatient) {
        await api.put('patients', selectedPatient.id, formData);
        addToast('Patient updated successfully!', 'success');
      } else {
        const patCode = `PAT-2026-${Math.floor(1000 + Math.random() * 9000)}`;
        await api.post('patients', { ...formData, patient_id: patCode });
        addToast('New Patient added successfully!', 'success');
      }
      setShowModal(false);
      fetchPatients();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  const filteredPatients = patients.filter(p =>
    p.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.patient_id?.toLowerCase().includes(search.toLowerCase()) ||
    p.phone?.includes(search)
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Patient Directory & Management</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Register and maintain comprehensive patient profiles and medical histories</p>
        </div>
        <button onClick={() => { setSelectedPatient(null); setShowModal(true); }} className="btn btn-primary">
          <Plus size={18} /> Add New Patient
        </button>
      </div>

      <div className="glass-card" style={{ padding: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', background: 'rgba(15,23,42,0.8)', padding: '0.65rem 1rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.08)' }}>
          <Search size={18} color="#0891b2" />
          <input
            type="text"
            placeholder="Search patient by name, PAT ID, or phone number..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ background: 'none', border: 'none', outline: 'none', color: '#fff', width: '100%', fontSize: '0.9rem' }}
          />
        </div>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Patient ID</th>
                <th>Full Name</th>
                <th>Age / Gender</th>
                <th>Blood Group</th>
                <th>Phone</th>
                <th>Emergency Contact</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPatients.map(p => (
                <tr key={p.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{p.patient_id}</td>
                  <td style={{ fontWeight: 600 }}>{p.full_name}</td>
                  <td>{p.age} y / {p.gender}</td>
                  <td><span className="badge badge-primary">{p.blood_group}</span></td>
                  <td>{p.phone}</td>
                  <td>{p.emergency_contact || 'N/A'}</td>
                  <td style={{ display: 'flex', gap: '0.5rem' }}>
                    <button onClick={() => { setSelectedPatient(p); setFormData(p); setShowModal(true); }} className="btn btn-secondary btn-sm">
                      <Edit size={14} /> Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{selectedPatient ? 'Edit Patient Profile' : 'Register New Patient'}</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSavePatient} className="modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Full Name</label>
                <input type="text" className="form-input" value={formData.full_name} onChange={e => setFormData({ ...formData, full_name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Date of Birth</label>
                <input type="date" className="form-input" value={formData.dob} onChange={e => setFormData({ ...formData, dob: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Gender</label>
                <select className="form-select" value={formData.gender} onChange={e => setFormData({ ...formData, gender: e.target.value })}>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Blood Group</label>
                <select className="form-select" value={formData.blood_group} onChange={e => setFormData({ ...formData, blood_group: e.target.value })}>
                  <option value="A+">A+</option><option value="A-">A-</option>
                  <option value="B+">B+</option><option value="B-">B-</option>
                  <option value="O+">O+</option><option value="O-">O-</option>
                  <option value="AB+">AB+</option><option value="AB-">AB-</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Phone Number</label>
                <input type="text" className="form-input" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} required />
              </div>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Address</label>
                <input type="text" className="form-input" value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} />
              </div>
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Medical History / Past Conditions</label>
                <textarea className="form-textarea" rows="2" value={formData.medical_history} onChange={e => setFormData({ ...formData, medical_history: e.target.value })}></textarea>
              </div>
              <div className="modal-footer" style={{ gridColumn: 'span 2', padding: 0 }}>
                <button type="submit" className="btn btn-primary">{selectedPatient ? 'Update Patient' : 'Save & Generate Patient ID'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
