import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useNotification } from '../../context/NotificationContext';
import { StatusBadge } from '../../components/StatusBadge';
import { Plus, Calendar, Clock, Stethoscope, User, AlertTriangle, X } from 'lucide-react';

export const AppointmentManagement = () => {
  const { addToast } = useNotification();
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    patient: '',
    doctor: '',
    department: '',
    date: new Date().toISOString().split('T')[0],
    time_slot: '10:00 AM',
    reason: ''
  });

  const availableSlots = [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM',
    '11:30 AM', '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM'
  ];

  const fetchAll = () => {
    api.get('appointments').then(setAppointments).catch(() => {});
    api.get('doctors').then(setDoctors).catch(() => {});
    api.get('patients').then(setPatients).catch(() => {});
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleDoctorChange = (docId) => {
    const doc = doctors.find(d => String(d.id) === String(docId));
    setFormData(prev => ({
      ...prev,
      doctor: docId,
      department: doc?.department || ''
    }));
  };

  const handleBookAppointment = async (e) => {
    e.preventDefault();
    if (!formData.patient || !formData.doctor) {
      addToast('Please select both patient and doctor', 'warning');
      return;
    }

    try {
      const aptCode = `APT-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      await api.post('appointments', { ...formData, appointment_id: aptCode });
      addToast('Appointment booked successfully!', 'success');
      setShowModal(false);
      fetchAll();
    } catch (err) {
      addToast(err.message || 'Double booking error! This doctor is already booked for the selected date & time slot.', 'error', 'Booking Rejected');
    }
  };

  const handleStatusChange = async (aptId, newStatus) => {
    try {
      await api.put('appointments', aptId, { status: newStatus });
      addToast(`Appointment status updated to ${newStatus}`, 'info');
      fetchAll();
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Appointment Booking & OPD Calendar</h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>Prevent double bookings, select time slots, and manage consultation schedules</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary">
          <Plus size={18} /> Book Appointment
        </button>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Appt ID</th>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Department</th>
                <th>Date & Slot</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map(apt => (
                <tr key={apt.id}>
                  <td style={{ fontWeight: 800, color: '#22d3ee' }}>{apt.appointment_id}</td>
                  <td style={{ fontWeight: 600 }}>{apt.patient_name}</td>
                  <td>{apt.doctor_name}</td>
                  <td>{apt.department_name}</td>
                  <td>{apt.date} at {apt.time_slot}</td>
                  <td><StatusBadge status={apt.status} /></td>
                  <td style={{ display: 'flex', gap: '0.4rem' }}>
                    {apt.status === 'PENDING' && (
                      <button onClick={() => handleStatusChange(apt.id, 'CONFIRMED')} className="btn btn-success btn-sm">
                        Confirm
                      </button>
                    )}
                    {apt.status === 'CONFIRMED' && (
                      <button onClick={() => handleStatusChange(apt.id, 'COMPLETED')} className="btn btn-primary btn-sm">
                        Mark Done
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Book New Consultation Appointment</h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', color: '#94a3b8' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleBookAppointment} className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Select Patient</label>
                <select className="form-select" value={formData.patient} onChange={e => setFormData({ ...formData, patient: e.target.value })} required>
                  <option value="">-- Choose Patient --</option>
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.full_name} ({p.patient_id})</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Select Doctor</label>
                <select className="form-select" value={formData.doctor} onChange={e => handleDoctorChange(e.target.value)} required>
                  <option value="">-- Choose Specialist Doctor --</option>
                  {doctors.map(d => (
                    <option key={d.id} value={d.id}>{d.doctor_name} - {d.specialization} (Fee: ₹{d.consultation_fee})</option>
                  ))}
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="form-group">
                  <label className="form-label">Appointment Date</label>
                  <input type="date" className="form-input" value={formData.date} onChange={e => setFormData({ ...formData, date: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Time Slot (Double-Booking Protected)</label>
                  <select className="form-select" value={formData.time_slot} onChange={e => setFormData({ ...formData, time_slot: e.target.value })}>
                    {availableSlots.map(slot => (
                      <option key={slot} value={slot}>{slot}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Reason for Visit / Symptoms</label>
                <textarea className="form-textarea" rows="2" value={formData.reason} onChange={e => setFormData({ ...formData, reason: e.target.value })} required></textarea>
              </div>

              <div className="modal-footer" style={{ padding: 0 }}>
                <button type="submit" className="btn btn-primary">Confirm & Book Appointment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
