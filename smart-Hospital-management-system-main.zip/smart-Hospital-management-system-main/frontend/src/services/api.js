const API_BASE_URL = 'http://localhost:8000/api';

const getAuthHeader = () => {
  const token = localStorage.getItem('hms_token');
  return token ? { 'Authorization': `Token ${token}` } : {};
};

export const api = {
  // Auth
  login: async (credentials) => {
    const res = await fetch(`${API_BASE_URL}/auth/login/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    return data;
  },

  registerPatient: async (patientData) => {
    const res = await fetch(`${API_BASE_URL}/auth/register/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patientData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Registration failed');
    return data;
  },

  me: async () => {
    const res = await fetch(`${API_BASE_URL}/auth/me/`, {
      headers: { ...getAuthHeader() }
    });
    if (!res.ok) throw new Error('Session expired');
    return res.json();
  },

  // Dashboard Stats
  getDashboardStats: async () => {
    const res = await fetch(`${API_BASE_URL}/dashboard/stats/`, {
      headers: { ...getAuthHeader() }
    });
    return res.json();
  },

  // Generic CRUD helpers
  get: async (endpoint) => {
    const res = await fetch(`${API_BASE_URL}/${endpoint}/`, {
      headers: { ...getAuthHeader() }
    });
    if (!res.ok) throw new Error(`Failed to fetch ${endpoint}`);
    return res.json();
  },

  post: async (endpoint, payload) => {
    const res = await fetch(`${API_BASE_URL}/${endpoint}/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader()
      },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) {
      const errMsg = typeof data === 'object' ? JSON.stringify(data) : 'Operation failed';
      throw new Error(errMsg);
    }
    return data;
  },

  put: async (endpoint, id, payload) => {
    const res = await fetch(`${API_BASE_URL}/${endpoint}/${id}/`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader()
      },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error('Update failed');
    return data;
  },

  delete: async (endpoint, id) => {
    const res = await fetch(`${API_BASE_URL}/${endpoint}/${id}/`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() }
    });
    if (!res.ok) throw new Error('Deletion failed');
    return true;
  },

  customAction: async (endpoint, id, actionName, payload = {}) => {
    const res = await fetch(`${API_BASE_URL}/${endpoint}/${id}/${actionName}/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader()
      },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error('Action failed');
    return data;
  }
};
