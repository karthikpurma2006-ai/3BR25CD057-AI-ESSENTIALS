import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';

import { LandingPage } from './pages/LandingPage';
import { Login } from './pages/Login';
import { Register } from './pages/Register';

import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { SearchModal } from './components/SearchModal';

// Dashboards
import { SuperAdminDashboard } from './pages/dashboards/SuperAdminDashboard';
import { DoctorDashboard } from './pages/dashboards/DoctorDashboard';
import { NurseDashboard } from './pages/dashboards/NurseDashboard';
import { ReceptionistDashboard } from './pages/dashboards/ReceptionistDashboard';
import { PharmacistDashboard } from './pages/dashboards/PharmacistDashboard';
import { LabStaffDashboard } from './pages/dashboards/LabStaffDashboard';
import { AccountantDashboard } from './pages/dashboards/AccountantDashboard';
import { PatientDashboard } from './pages/dashboards/PatientDashboard';

// Modules
import { PatientManagement } from './pages/modules/PatientManagement';
import { DoctorManagement } from './pages/modules/DoctorManagement';
import { DepartmentManagement } from './pages/modules/DepartmentManagement';
import { AppointmentManagement } from './pages/modules/AppointmentManagement';
import { OPDManagement } from './pages/modules/OPDManagement';
import { AdmissionDischarge } from './pages/modules/AdmissionDischarge';
import { WardBedManagement } from './pages/modules/WardBedManagement';
import { EMRManagement } from './pages/modules/EMRManagement';
import { PrescriptionManagement } from './pages/modules/PrescriptionManagement';
import { PharmacyManagement } from './pages/modules/PharmacyManagement';
import { LaboratoryManagement } from './pages/modules/LaboratoryManagement';
import { EmergencyManagement } from './pages/modules/EmergencyManagement';
import { BillingPayment } from './pages/modules/BillingPayment';
import { InventoryManagement } from './pages/modules/InventoryManagement';
import { StaffManagement } from './pages/modules/StaffManagement';
import { ReportsAnalytics } from './pages/modules/ReportsAnalytics';
import { AuditLogs } from './pages/modules/AuditLogs';

const MainLayout = () => {
  const { user, loading } = useAuth();
  const [activeModule, setActiveModule] = useState('dashboard');
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  if (loading) {
    return (
      <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center', background: '#090d16', color: '#22d3ee' }}>
        <h2>Loading Sanjeevini Multispeciality Hospital...</h2>
      </div>
    );
  }

  // If user is not logged in, render Public Landing Page
  if (!user) {
    return (
      <>
        <LandingPage
          onOpenLogin={() => setShowLoginModal(true)}
          onOpenRegister={() => setShowRegisterModal(true)}
          onBookAppointmentClick={() => setShowLoginModal(true)}
        />

        {showLoginModal && (
          <Login
            onClose={() => setShowLoginModal(false)}
            onSwitchToRegister={() => { setShowLoginModal(false); setShowRegisterModal(true); }}
          />
        )}

        {showRegisterModal && (
          <Register
            onClose={() => setShowRegisterModal(false)}
            onSwitchToLogin={() => { setShowRegisterModal(false); setShowLoginModal(true); }}
          />
        )}
      </>
    );
  }

  // Render Role Dashboard
  const renderDashboardForRole = () => {
    switch (user.role) {
      case 'SUPER_ADMIN':
      case 'HOSPITAL_ADMIN':
        return <SuperAdminDashboard setActiveModule={setActiveModule} />;
      case 'DOCTOR':
        return <DoctorDashboard setActiveModule={setActiveModule} />;
      case 'NURSE':
        return <NurseDashboard setActiveModule={setActiveModule} />;
      case 'RECEPTIONIST':
        return <ReceptionistDashboard setActiveModule={setActiveModule} />;
      case 'PHARMACIST':
        return <PharmacistDashboard setActiveModule={setActiveModule} />;
      case 'LAB_STAFF':
        return <LabStaffDashboard setActiveModule={setActiveModule} />;
      case 'ACCOUNTANT':
        return <AccountantDashboard setActiveModule={setActiveModule} />;
      case 'PATIENT':
        return <PatientDashboard setActiveModule={setActiveModule} />;
      default:
        return <SuperAdminDashboard setActiveModule={setActiveModule} />;
    }
  };

  // Render Selected Module
  const renderContent = () => {
    switch (activeModule) {
      case 'dashboard': return renderDashboardForRole();
      case 'patients': return <PatientManagement />;
      case 'doctors': return <DoctorManagement />;
      case 'departments': return <DepartmentManagement />;
      case 'appointments': return <AppointmentManagement />;
      case 'opd': return <OPDManagement />;
      case 'admissions': return <AdmissionDischarge />;
      case 'wards': return <WardBedManagement />;
      case 'emr': return <EMRManagement />;
      case 'prescriptions': return <PrescriptionManagement />;
      case 'pharmacy': return <PharmacyManagement />;
      case 'laboratory': return <LaboratoryManagement />;
      case 'nursing': return <NurseDashboard setActiveModule={setActiveModule} />;
      case 'emergency': return <EmergencyManagement />;
      case 'billing': return <BillingPayment />;
      case 'inventory': return <InventoryManagement />;
      case 'staff': return <StaffManagement />;
      case 'reports': return <ReportsAnalytics />;
      case 'audit': return <AuditLogs />;
      default: return renderDashboardForRole();
    }
  };

  return (
    <div className="app-container">
      <Sidebar activeModule={activeModule} setActiveModule={setActiveModule} />
      <div className="main-content">
        <Navbar
          onOpenSearch={() => setShowSearchModal(true)}
          activeModule={activeModule}
          setActiveModule={setActiveModule}
        />
        <main className="page-wrapper">
          {renderContent()}
        </main>
      </div>

      <SearchModal
        isOpen={showSearchModal}
        onClose={() => setShowSearchModal(false)}
        onSelectResult={(mod, item) => setActiveModule(mod)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <MainLayout />
      </NotificationProvider>
    </AuthProvider>
  );
}
