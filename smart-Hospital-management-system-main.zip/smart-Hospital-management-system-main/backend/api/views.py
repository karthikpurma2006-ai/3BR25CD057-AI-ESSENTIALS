from rest_framework import viewsets, permissions, status
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate, get_user_model
from django.db.models import Count, Sum, Q, F
from django.utils import timezone
import random, string

from .models import (
    UserRole, Department, Doctor, Patient, Staff, Appointment, OPDToken,
    Ward, Bed, Admission, EmergencyCase, EMRRecord, Prescription, Medicine,
    PharmacySale, LabTest, LabReport, NursingVitals, Bill, Payment,
    InventoryItem, Notification, AuditLog
)
from .serializers import (
    UserSerializer, DepartmentSerializer, DoctorSerializer, PatientSerializer,
    StaffSerializer, AppointmentSerializer, OPDTokenSerializer, WardSerializer,
    BedSerializer, AdmissionSerializer, EmergencyCaseSerializer, EMRRecordSerializer,
    PrescriptionSerializer, MedicineSerializer, PharmacySaleSerializer, LabTestSerializer,
    LabReportSerializer, NursingVitalsSerializer, BillSerializer, PaymentSerializer,
    InventoryItemSerializer, NotificationSerializer, AuditLogSerializer
)

User = get_user_model()

def log_action(user, action, module, details=""):
    try:
        AuditLog.objects.create(
            user=user if user and user.is_authenticated else None,
            user_role=user.role if user and user.is_authenticated else "GUEST",
            action=action,
            module=module,
            details=details
        )
    except Exception as e:
        print("Audit log error:", e)

# ----------------- AUTH VIEWS ----------------- #

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def login_view(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    if not username or not password:
        return Response({'error': 'Username and password are required.'}, status=status.HTTP_400_BAD_REQUEST)
    
    user = authenticate(username=username, password=password)
    if not user:
        # Fallback check by email
        try:
            u = User.objects.get(email=username)
            user = authenticate(username=u.username, password=password)
        except User.DoesNotExist:
            user = None

    if not user:
        return Response({'error': 'Invalid credentials. Please check your username and password.'}, status=status.HTTP_401_UNAUTHORIZED)
    
    token, _ = Token.objects.get_or_create(user=user)
    
    log_action(user, f"User logged in ({user.role})", "Authentication", f"User {user.username} logged in successfully.")
    
    patient_id = None
    doctor_id = None
    if hasattr(user, 'patient_profile'):
        patient_id = user.patient_profile.id
    if hasattr(user, 'doctor_profile'):
        doctor_id = user.doctor_profile.id

    return Response({
        'token': token.key,
        'user': UserSerializer(user).data,
        'patient_id': patient_id,
        'doctor_id': doctor_id
    })

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def register_patient_view(request):
    data = request.data
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name', username)
    phone = data.get('phone', '')

    if User.objects.filter(username=username).exists():
        return Response({'error': 'Username already exists.'}, status=status.HTTP_400_BAD_REQUEST)

    user = User.objects.create_user(
        username=username,
        email=email,
        password=password,
        first_name=full_name.split(' ')[0] if full_name else username,
        last_name=' '.join(full_name.split(' ')[1:]) if full_name and len(full_name.split(' ')) > 1 else '',
        role=UserRole.PATIENT,
        phone=phone
    )

    pat_code = f"PAT-{timezone.now().year}-{''.join(random.choices(string.digits, k=4))}"
    patient = Patient.objects.create(
        user=user,
        patient_id=pat_code,
        full_name=full_name,
        phone=phone,
        email=email,
        dob=data.get('dob', None),
        gender=data.get('gender', 'Male'),
        blood_group=data.get('blood_group', 'O+'),
        address=data.get('address', '')
    )

    token, _ = Token.objects.get_or_create(user=user)
    log_action(user, "Patient Registered", "Patient Portal", f"New patient registered: {full_name}")

    return Response({
        'token': token.key,
        'user': UserSerializer(user).data,
        'patient_id': patient.id
    }, status=status.HTTP_201_CREATED)

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def me_view(request):
    user = request.user
    patient_id = getattr(user, 'patient_profile', None).id if hasattr(user, 'patient_profile') and user.patient_profile else None
    doctor_id = getattr(user, 'doctor_profile', None).id if hasattr(user, 'doctor_profile') and user.doctor_profile else None

    return Response({
        'user': UserSerializer(user).data,
        'patient_id': patient_id,
        'doctor_id': doctor_id
    })

# ----------------- DASHBOARD & STATS VIEWS ----------------- #

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def dashboard_stats(request):
    today = timezone.now().date()
    
    total_patients = Patient.objects.count()
    total_doctors = Doctor.objects.count()
    total_staff = Staff.objects.count() + total_doctors
    today_appointments = Appointment.objects.filter(date=today).count()
    today_admissions = Admission.objects.filter(admission_date__date=today).count()
    
    beds = Bed.objects.all()
    available_beds = beds.filter(status='AVAILABLE').count()
    occupied_beds = beds.filter(status='OCCUPIED').count()
    
    pending_bills = Bill.objects.filter(status='PENDING').count()
    low_stock_medicines = Medicine.objects.filter(quantity__lte=F('min_threshold')).count()
    pending_lab_tests = LabReport.objects.filter(status='REQUESTED').count()
    active_emergencies = EmergencyCase.objects.filter(status='ACTIVE').count()
    
    total_revenue = Bill.objects.aggregate(total=Sum('paid_amount'))['total'] or 0.00

    # Chart datasets
    # Monthly Appointments
    dept_stats = Department.objects.annotate(doc_count=Count('doctors')).values('name', 'doc_count')
    
    return Response({
        'total_patients': total_patients,
        'total_doctors': total_doctors,
        'total_staff': total_staff,
        'today_appointments': today_appointments,
        'today_admissions': today_admissions,
        'available_beds': available_beds,
        'occupied_beds': occupied_beds,
        'pending_bills': pending_bills,
        'low_stock_medicines': low_stock_medicines,
        'pending_lab_tests': pending_lab_tests,
        'active_emergencies': active_emergencies,
        'total_revenue': float(total_revenue),
        'department_distribution': list(dept_stats)
    })

# ----------------- VIEWSETS ----------------- #

class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all().order_by('name')
    serializer_class = DepartmentSerializer
    permission_classes = [permissions.AllowAny]

class DoctorViewSet(viewsets.ModelViewSet):
    queryset = Doctor.objects.select_related('user', 'department').all()
    serializer_class = DoctorSerializer
    permission_classes = [permissions.AllowAny]

    def perform_create(self, serializer):
        doc = serializer.save()
        log_action(self.request.user, f"Doctor Added: {doc.doctor_id}", "Doctor Management")

class PatientViewSet(viewsets.ModelViewSet):
    queryset = Patient.objects.all().order_by('-created_at')
    serializer_class = PatientSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        patient = serializer.save()
        log_action(self.request.user, f"Patient Registered: {patient.patient_id}", "Patient Management")

class StaffViewSet(viewsets.ModelViewSet):
    queryset = Staff.objects.select_related('user', 'department').all()
    serializer_class = StaffSerializer
    permission_classes = [permissions.IsAuthenticated]

class AppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.select_related('patient', 'doctor', 'department').all().order_by('-date', 'time_slot')
    serializer_class = AppointmentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        appt = serializer.save()
        log_action(self.request.user, f"Appointment Booked: {appt.appointment_id}", "Appointment Management")
        # Create notification for doctor & patient
        if appt.patient.user:
            Notification.objects.create(
                user=appt.patient.user,
                title="Appointment Booked",
                message=f"Your appointment with Dr. {appt.doctor.user.last_name} is confirmed for {appt.date} at {appt.time_slot}.",
                type="APPOINTMENT"
            )

class OPDTokenViewSet(viewsets.ModelViewSet):
    queryset = OPDToken.objects.select_related('patient', 'doctor').all().order_by('-date', 'token_number')
    serializer_class = OPDTokenSerializer
    permission_classes = [permissions.IsAuthenticated]

class WardViewSet(viewsets.ModelViewSet):
    queryset = Ward.objects.prefetch_related('beds').all()
    serializer_class = WardSerializer
    permission_classes = [permissions.IsAuthenticated]

class BedViewSet(viewsets.ModelViewSet):
    queryset = Bed.objects.select_related('ward').all()
    serializer_class = BedSerializer
    permission_classes = [permissions.IsAuthenticated]

class AdmissionViewSet(viewsets.ModelViewSet):
    queryset = Admission.objects.select_related('patient', 'doctor', 'bed').all().order_by('-admission_date')
    serializer_class = AdmissionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        admission = serializer.save()
        if admission.bed:
            admission.bed.status = 'OCCUPIED'
            admission.bed.save()
        log_action(self.request.user, f"Patient Admitted: {admission.admission_id}", "Admission Management")

    @action(detail=True, methods=['post'])
    def discharge(self, request, pk=None):
        admission = self.get_object()
        admission.status = 'DISCHARGED'
        admission.actual_discharge = timezone.now()
        admission.discharge_summary = request.data.get('discharge_summary', 'Discharged in stable condition.')
        admission.diagnosis_at_discharge = request.data.get('diagnosis_at_discharge', '')
        admission.save()

        # Free the bed
        if admission.bed:
            admission.bed.status = 'AVAILABLE'
            admission.bed.save()

        log_action(request.user, f"Patient Discharged: {admission.admission_id}", "Discharge Management")
        return Response({'status': 'Patient discharged successfully.', 'admission': AdmissionSerializer(admission).data})

class EmergencyCaseViewSet(viewsets.ModelViewSet):
    queryset = EmergencyCase.objects.all().order_by('-created_at')
    serializer_class = EmergencyCaseSerializer
    permission_classes = [permissions.IsAuthenticated]

class EMRRecordViewSet(viewsets.ModelViewSet):
    queryset = EMRRecord.objects.select_related('patient', 'doctor').all().order_by('-created_at')
    serializer_class = EMRRecordSerializer
    permission_classes = [permissions.IsAuthenticated]

class PrescriptionViewSet(viewsets.ModelViewSet):
    queryset = Prescription.objects.select_related('patient', 'doctor').all().order_by('-created_at')
    serializer_class = PrescriptionSerializer
    permission_classes = [permissions.IsAuthenticated]

class MedicineViewSet(viewsets.ModelViewSet):
    queryset = Medicine.objects.all().order_by('name')
    serializer_class = MedicineSerializer
    permission_classes = [permissions.IsAuthenticated]

class PharmacySaleViewSet(viewsets.ModelViewSet):
    queryset = PharmacySale.objects.all().order_by('-date')
    serializer_class = PharmacySaleSerializer
    permission_classes = [permissions.IsAuthenticated]

class LabTestViewSet(viewsets.ModelViewSet):
    queryset = LabTest.objects.all().order_by('name')
    serializer_class = LabTestSerializer
    permission_classes = [permissions.AllowAny]

class LabReportViewSet(viewsets.ModelViewSet):
    queryset = LabReport.objects.select_related('patient', 'doctor', 'lab_test').all().order_by('-request_date')
    serializer_class = LabReportSerializer
    permission_classes = [permissions.IsAuthenticated]

class NursingVitalsViewSet(viewsets.ModelViewSet):
    queryset = NursingVitals.objects.select_related('patient', 'nurse').all().order_by('-recorded_at')
    serializer_class = NursingVitalsSerializer
    permission_classes = [permissions.IsAuthenticated]

class BillViewSet(viewsets.ModelViewSet):
    queryset = Bill.objects.select_related('patient').all().order_by('-created_at')
    serializer_class = BillSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=True, methods=['post'])
    def add_payment(self, request, pk=None):
        bill = self.get_object()
        amount = float(request.data.get('amount', 0))
        method = request.data.get('payment_method', 'CASH')
        
        pay_code = f"PAY-{''.join(random.choices(string.digits, k=6))}"
        payment = Payment.objects.create(
            payment_code=pay_code,
            bill=bill,
            amount=amount,
            payment_method=method,
            status='SUCCESS'
        )

        bill.paid_amount = float(bill.paid_amount) + amount
        bill.balance_amount = max(0, float(bill.total_amount) - float(bill.paid_amount))
        if bill.balance_amount <= 0:
            bill.status = 'PAID'
        else:
            bill.status = 'PARTIALLY_PAID'
        bill.save()

        log_action(request.user, f"Payment Processed: ₹{amount} for Bill {bill.bill_code}", "Billing & Payments")
        return Response({'status': 'Payment recorded successfully', 'bill': BillSerializer(bill).data})

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all().order_by('-payment_date')
    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]

class InventoryItemViewSet(viewsets.ModelViewSet):
    queryset = InventoryItem.objects.all().order_by('name')
    serializer_class = InventoryItemSerializer
    permission_classes = [permissions.IsAuthenticated]

class NotificationViewSet(viewsets.ModelViewSet):
    queryset = Notification.objects.all().order_by('-created_at')
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user).order_by('-created_at')

    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
        return Response({'status': 'All notifications marked as read.'})

class AuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = AuditLog.objects.select_related('user').all().order_by('-timestamp')
    serializer_class = AuditLogSerializer
    permission_classes = [permissions.IsAuthenticated]
