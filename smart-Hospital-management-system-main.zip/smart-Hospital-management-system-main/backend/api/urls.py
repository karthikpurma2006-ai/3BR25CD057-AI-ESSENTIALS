from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    login_view, register_patient_view, me_view, dashboard_stats,
    DepartmentViewSet, DoctorViewSet, PatientViewSet, StaffViewSet,
    AppointmentViewSet, OPDTokenViewSet, WardViewSet, BedViewSet,
    AdmissionViewSet, EmergencyCaseViewSet, EMRRecordViewSet,
    PrescriptionViewSet, MedicineViewSet, PharmacySaleViewSet,
    LabTestViewSet, LabReportViewSet, NursingVitalsViewSet,
    BillViewSet, PaymentViewSet, InventoryItemViewSet,
    NotificationViewSet, AuditLogViewSet
)

router = DefaultRouter()
router.register(r'departments', DepartmentViewSet)
router.register(r'doctors', DoctorViewSet)
router.register(r'patients', PatientViewSet)
router.register(r'staff', StaffViewSet)
router.register(r'appointments', AppointmentViewSet)
router.register(r'opd-tokens', OPDTokenViewSet)
router.register(r'wards', WardViewSet)
router.register(r'beds', BedViewSet)
router.register(r'admissions', AdmissionViewSet)
router.register(r'emergencies', EmergencyCaseViewSet)
router.register(r'emr', EMRRecordViewSet)
router.register(r'prescriptions', PrescriptionViewSet)
router.register(r'medicines', MedicineViewSet)
router.register(r'pharmacy-sales', PharmacySaleViewSet)
router.register(r'lab-tests', LabTestViewSet)
router.register(r'lab-reports', LabReportViewSet)
router.register(r'nursing-vitals', NursingVitalsViewSet)
router.register(r'bills', BillViewSet)
router.register(r'payments', PaymentViewSet)
router.register(r'inventory', InventoryItemViewSet)
router.register(r'notifications', NotificationViewSet)
router.register(r'audit-logs', AuditLogViewSet)

urlpatterns = [
    path('auth/login/', login_view, name='login'),
    path('auth/register/', register_patient_view, name='register_patient'),
    path('auth/me/', me_view, name='auth_me'),
    path('dashboard/stats/', dashboard_stats, name='dashboard_stats'),
    path('', include(router.urls)),
]
