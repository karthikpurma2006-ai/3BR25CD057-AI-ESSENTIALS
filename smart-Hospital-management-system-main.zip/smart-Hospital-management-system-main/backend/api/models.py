from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
import uuid

class UserRole(models.TextChoices):
    SUPER_ADMIN = 'SUPER_ADMIN', 'Super Admin'
    HOSPITAL_ADMIN = 'HOSPITAL_ADMIN', 'Hospital Admin'
    DOCTOR = 'DOCTOR', 'Doctor'
    NURSE = 'NURSE', 'Nurse'
    RECEPTIONIST = 'RECEPTIONIST', 'Receptionist'
    PHARMACIST = 'PHARMACIST', 'Pharmacist'
    LAB_STAFF = 'LAB_STAFF', 'Laboratory Staff'
    ACCOUNTANT = 'ACCOUNTANT', 'Accountant'
    PATIENT = 'PATIENT', 'Patient'

class User(AbstractUser):
    role = models.CharField(max_length=20, choices=UserRole.choices, default=UserRole.PATIENT)
    phone = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    profile_photo = models.ImageField(upload_to='profiles/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.role})"

class Department(models.Model):
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=20, unique=True)
    description = models.TextField(blank=True, null=True)
    icon = models.CharField(max_length=50, default='Activity')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Doctor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='doctor_profile')
    doctor_id = models.CharField(max_length=20, unique=True)
    specialization = models.CharField(max_length=100)
    qualification = models.CharField(max_length=150)
    experience_years = models.IntegerField(default=1)
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, related_name='doctors')
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2, default=500.00)
    available_days = models.JSONField(default=list) # e.g. ["Mon", "Tue", "Wed", "Thu", "Fri"]
    available_times = models.CharField(max_length=100, default="09:00 AM - 05:00 PM")
    is_approved = models.BooleanField(default=True)

    def __str__(self):
        return f"Dr. {self.user.get_full_name() or self.user.username} ({self.specialization})"

class Patient(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='patient_profile', null=True, blank=True)
    patient_id = models.CharField(max_length=20, unique=True) # PAT-2026-0001
    full_name = models.CharField(max_length=150)
    dob = models.DateField(null=True, blank=True)
    age = models.IntegerField(default=30)
    gender = models.CharField(max_length=15, choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])
    blood_group = models.CharField(max_length=10, default='O+')
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    emergency_contact = models.CharField(max_length=100, blank=True, null=True)
    medical_history = models.TextField(blank=True, null=True)
    allergies = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.patient_id} - {self.full_name}"

class Staff(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='staff_profile')
    employee_id = models.CharField(max_length=20, unique=True)
    role = models.CharField(max_length=20, choices=UserRole.choices)
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True)
    qualification = models.CharField(max_length=150, blank=True, null=True)
    joining_date = models.DateField(default=timezone.now)
    salary = models.DecimalField(max_digits=10, decimal_places=2, default=30000.00)
    status = models.CharField(max_length=20, default='ACTIVE')

    def __str__(self):
        return f"{self.employee_id} - {self.user.get_full_name() or self.user.username} ({self.role})"

class AppointmentStatus(models.TextChoices):
    PENDING = 'PENDING', 'Pending'
    CONFIRMED = 'CONFIRMED', 'Confirmed'
    COMPLETED = 'COMPLETED', 'Completed'
    CANCELLED = 'CANCELLED', 'Cancelled'
    REJECTED = 'REJECTED', 'Rejected'

class Appointment(models.Model):
    appointment_id = models.CharField(max_length=20, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='appointments')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='appointments')
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True)
    date = models.DateField()
    time_slot = models.CharField(max_length=50) # e.g., "10:00 AM"
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=AppointmentStatus.choices, default=AppointmentStatus.PENDING)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('doctor', 'date', 'time_slot')

    def __str__(self):
        return f"Appt {self.appointment_id}: {self.patient.full_name} with Dr. {self.doctor.user.last_name}"

class OPDToken(models.Model):
    token_number = models.IntegerField()
    token_code = models.CharField(max_length=20, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    date = models.DateField(default=timezone.now)
    status = models.CharField(max_length=20, default='WAITING')
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2, default=500.00)
    is_paid = models.BooleanField(default=True)

    def __str__(self):
        return f"OPD Token #{self.token_number} - {self.patient.full_name}"

class Ward(models.Model):
    WARD_TYPES = [
        ('GENERAL', 'General Ward'),
        ('ICU', 'ICU'),
        ('EMERGENCY', 'Emergency Ward'),
        ('PRIVATE', 'Private Room'),
        ('SEMI_PRIVATE', 'Semi-Private Room'),
    ]
    name = models.CharField(max_length=100)
    ward_type = models.CharField(max_length=30, choices=WARD_TYPES)
    total_beds = models.IntegerField(default=10)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.get_ward_type_display()})"

class Bed(models.Model):
    BED_STATUS = [
        ('AVAILABLE', 'Available'),
        ('OCCUPIED', 'Occupied'),
        ('RESERVED', 'Reserved'),
        ('MAINTENANCE', 'Maintenance'),
    ]
    ward = models.ForeignKey(Ward, on_delete=models.CASCADE, related_name='beds')
    bed_number = models.CharField(max_length=20)
    status = models.CharField(max_length=20, choices=BED_STATUS, default='AVAILABLE')
    daily_rate = models.DecimalField(max_digits=10, decimal_places=2, default=1000.00)

    def __str__(self):
        return f"{self.bed_number} ({self.ward.name}) - {self.status}"

class Admission(models.Model):
    admission_id = models.CharField(max_length=20, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='admissions')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    bed = models.ForeignKey(Bed, on_delete=models.SET_NULL, null=True)
    admission_date = models.DateTimeField(default=timezone.now)
    expected_discharge = models.DateField(null=True, blank=True)
    actual_discharge = models.DateTimeField(null=True, blank=True)
    admission_reason = models.TextField()
    discharge_summary = models.TextField(blank=True, null=True)
    diagnosis_at_discharge = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, default='ADMITTED')

    def __str__(self):
        return f"Admission {self.admission_id} - {self.patient.full_name}"

class EmergencyCase(models.Model):
    PRIORITY_LEVELS = [
        ('CRITICAL', 'Critical'),
        ('HIGH', 'High'),
        ('MEDIUM', 'Medium'),
        ('LOW', 'Low'),
    ]
    case_id = models.CharField(max_length=20, unique=True)
    patient_name = models.CharField(max_length=150)
    age = models.IntegerField(default=30)
    gender = models.CharField(max_length=15)
    contact = models.CharField(max_length=30)
    priority = models.CharField(max_length=20, choices=PRIORITY_LEVELS, default='HIGH')
    assigned_doctor = models.ForeignKey(Doctor, on_delete=models.SET_NULL, null=True, blank=True)
    assigned_nurse = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, limit_choices_to={'role': 'NURSE'})
    bed = models.ForeignKey(Bed, on_delete=models.SET_NULL, null=True, blank=True)
    treatment_notes = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, default='ACTIVE')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"EMG {self.case_id} [{self.priority}] - {self.patient_name}"

class EMRRecord(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='emr_records')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    visit_date = models.DateField(default=timezone.now)
    symptoms = models.TextField()
    diagnosis = models.TextField()
    vital_signs = models.JSONField(default=dict)
    treatment_plan = models.TextField(blank=True, null=True)
    doctor_notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"EMR for {self.patient.full_name} on {self.visit_date}"

class Prescription(models.Model):
    prescription_code = models.CharField(max_length=20, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='prescriptions')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    appointment = models.ForeignKey(Appointment, on_delete=models.SET_NULL, null=True, blank=True)
    date = models.DateField(default=timezone.now)
    diagnosis = models.TextField()
    items = models.JSONField(default=list)
    status = models.CharField(max_length=20, default='ACTIVE')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Rx {self.prescription_code} - {self.patient.full_name}"

class Medicine(models.Model):
    medicine_code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    category = models.CharField(max_length=100)
    manufacturer = models.CharField(max_length=150)
    batch_number = models.CharField(max_length=50)
    quantity = models.IntegerField(default=100)
    min_threshold = models.IntegerField(default=20)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=50.00)
    expiry_date = models.DateField()
    supplier = models.CharField(max_length=150, blank=True, null=True)

    def is_low_stock(self):
        return self.quantity <= self.min_threshold

    def is_expired(self):
        return self.expiry_date <= timezone.now().date()

    def __str__(self):
        return f"{self.name} (Qty: {self.quantity})"

class PharmacySale(models.Model):
    sale_code = models.CharField(max_length=20, unique=True)
    prescription = models.ForeignKey(Prescription, on_delete=models.SET_NULL, null=True, blank=True)
    patient = models.ForeignKey(Patient, on_delete=models.SET_NULL, null=True, blank=True)
    items = models.JSONField(default=list)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    final_amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Sale {self.sale_code} - ₹{self.final_amount}"

class LabTest(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    category = models.CharField(max_length=100)
    cost = models.DecimalField(max_digits=10, decimal_places=2, default=500.00)
    normal_range = models.CharField(max_length=150, blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.code})"

class LabReport(models.Model):
    STATUS_CHOICES = [
        ('REQUESTED', 'Requested'),
        ('SAMPLE_COLLECTED', 'Sample Collected'),
        ('PROCESSING', 'Processing'),
        ('COMPLETED', 'Completed'),
        ('CANCELLED', 'Cancelled'),
    ]
    report_code = models.CharField(max_length=20, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='lab_reports')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    lab_test = models.ForeignKey(LabTest, on_delete=models.CASCADE)
    request_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='REQUESTED')
    results_summary = models.TextField(blank=True, null=True)
    sample_details = models.CharField(max_length=150, blank=True, null=True)

    def __str__(self):
        return f"Lab {self.report_code}: {self.lab_test.name} - {self.status}"

class NursingVitals(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='vitals')
    nurse = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, limit_choices_to={'role': 'NURSE'})
    recorded_at = models.DateTimeField(default=timezone.now)
    temperature = models.CharField(max_length=20, default='98.6 °F')
    blood_pressure = models.CharField(max_length=20, default='120/80 mmHg')
    heart_rate = models.CharField(max_length=20, default='72 bpm')
    oxygen_saturation = models.CharField(max_length=20, default='98 %')
    respiratory_rate = models.CharField(max_length=20, default='16 bpm')
    notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Vitals for {self.patient.full_name} at {self.recorded_at.strftime('%Y-%m-%d %H:%M')}"

class Bill(models.Model):
    BILL_STATUS = [
        ('PENDING', 'Pending'),
        ('PARTIALLY_PAID', 'Partially Paid'),
        ('PAID', 'Paid'),
    ]
    bill_code = models.CharField(max_length=20, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='bills')
    admission = models.ForeignKey(Admission, on_delete=models.SET_NULL, null=True, blank=True)
    appointment = models.ForeignKey(Appointment, on_delete=models.SET_NULL, null=True, blank=True)
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    room_charges = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    lab_charges = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    pharmacy_charges = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    procedure_charges = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    paid_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    balance_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    status = models.CharField(max_length=20, choices=BILL_STATUS, default='PENDING')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Bill {self.bill_code} - {self.patient.full_name} (₹{self.total_amount})"

class Payment(models.Model):
    payment_code = models.CharField(max_length=20, unique=True)
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE, related_name='payments')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=20, choices=[('CASH', 'Cash'), ('CARD', 'Card'), ('UPI', 'UPI'), ('ONLINE', 'Online')])
    payment_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default='SUCCESS')

    def __str__(self):
        return f"Pay {self.payment_code} - ₹{self.amount} via {self.payment_method}"

class InventoryItem(models.Model):
    item_code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    category = models.CharField(max_length=100)
    quantity = models.IntegerField(default=50)
    unit = models.CharField(max_length=20, default='pcs')
    reorder_level = models.IntegerField(default=10)
    supplier = models.CharField(max_length=150, blank=True, null=True)
    purchase_date = models.DateField(default=timezone.now)
    expiry_date = models.DateField(null=True, blank=True)

    def is_low_stock(self):
        return self.quantity <= self.reorder_level

    def __str__(self):
        return f"{self.name} ({self.quantity} {self.unit})"

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=150)
    message = models.TextField()
    type = models.CharField(max_length=30, default='SYSTEM')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Notif to {self.user.username}: {self.title}"

class AuditLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    user_role = models.CharField(max_length=30, blank=True, null=True)
    action = models.CharField(max_length=150)
    module = models.CharField(max_length=100)
    details = models.TextField(blank=True, null=True)
    ip_address = models.CharField(max_length=45, default='127.0.0.1')
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"[{self.timestamp.strftime('%Y-%m-%d %H:%M')}] {self.user_role} - {self.action}"
