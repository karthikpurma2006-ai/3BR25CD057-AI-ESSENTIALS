import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'medicare_hms.settings')
django.setup()

from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta
import random

from api.models import (
    UserRole, Department, Doctor, Patient, Staff, Appointment, AppointmentStatus,
    OPDToken, Ward, Bed, Admission, EmergencyCase, EMRRecord, Prescription,
    Medicine, PharmacySale, LabTest, LabReport, NursingVitals, Bill, Payment,
    InventoryItem, Notification, AuditLog
)

User = get_user_model()

def run_seed():
    print("Flushing existing data...")
    # Clear tables
    AuditLog.objects.all().delete()
    Notification.objects.all().delete()
    Payment.objects.all().delete()
    Bill.objects.all().delete()
    NursingVitals.objects.all().delete()
    LabReport.objects.all().delete()
    LabTest.objects.all().delete()
    PharmacySale.objects.all().delete()
    Medicine.objects.all().delete()
    Prescription.objects.all().delete()
    EMRRecord.objects.all().delete()
    EmergencyCase.objects.all().delete()
    Admission.objects.all().delete()
    Bed.objects.all().delete()
    Ward.objects.all().delete()
    OPDToken.objects.all().delete()
    Appointment.objects.all().delete()
    Staff.objects.all().delete()
    Patient.objects.all().delete()
    Doctor.objects.all().delete()
    Department.objects.all().delete()
    User.objects.exclude(is_superuser=True).delete()

    print("Creating Demo Role Users (Password: Password123!)...")
    roles_info = [
        ('admin', 'admin@medicare.com', UserRole.SUPER_ADMIN, 'Super', 'Admin'),
        ('hospadmin', 'hospadmin@medicare.com', UserRole.HOSPITAL_ADMIN, 'Hospital', 'Administrator'),
        ('dr.smith', 'dr.smith@medicare.com', UserRole.DOCTOR, 'Robert', 'Smith'),
        ('nurse.sarah', 'nurse.sarah@medicare.com', UserRole.NURSE, 'Sarah', 'Jenkins'),
        ('receptionist', 'receptionist@medicare.com', UserRole.RECEPTIONIST, 'Rachel', 'Adams'),
        ('pharmacist', 'pharmacist@medicare.com', UserRole.PHARMACIST, 'Peter', 'Parker'),
        ('labtech', 'labtech@medicare.com', UserRole.LAB_STAFF, 'Lucas', 'Vance'),
        ('accountant', 'accountant@medicare.com', UserRole.ACCOUNTANT, 'Arthur', 'Pence'),
        ('patient.john', 'patient.john@medicare.com', UserRole.PATIENT, 'John', 'Doe'),
    ]

    user_map = {}
    for username, email, role, fname, lname in roles_info:
        user = User.objects.create_user(
            username=username,
            email=email,
            password='Password123!',
            first_name=fname,
            last_name=lname,
            role=role,
            phone='+1 (555) 019-2831' if role == UserRole.PATIENT else '+1 (555) 012-3456',
            address='124 Healthcare Boulevard, Cityville'
        )
        user_map[role] = user

    print("Creating Departments...")
    depts_data = [
        ('Cardiology', 'CARD', 'Heart and cardiovascular system care', 'Heart'),
        ('Neurology', 'NEURO', 'Brain and nervous system treatment', 'Brain'),
        ('Orthopedics', 'ORTHO', 'Bones, joints, and muscular surgery', 'Bone'),
        ('Pediatrics', 'PED', 'Comprehensive child healthcare', 'Baby'),
        ('General Medicine', 'GEN', 'Primary care and internal medicine', 'Stethoscope'),
    ]
    dept_objs = []
    for name, code, desc, icon in depts_data:
        d = Department.objects.create(name=name, code=code, description=desc, icon=icon)
        dept_objs.append(d)

    print("Creating Doctors...")
    doctor_names = [
        ('Robert', 'Smith', 'Cardiology', 'MD, FACC', 12, dept_objs[0]),
        ('Emily', 'Watson', 'Neurology', 'MD, DM Neurology', 8, dept_objs[1]),
        ('Michael', 'Chang', 'Orthopedics', 'MS Ortho', 15, dept_objs[2]),
        ('Sophia', 'Martinez', 'Pediatrics', 'MD Pediatrics', 10, dept_objs[3]),
        ('David', 'Johnson', 'General Medicine', 'MBBS, MD Internal Med', 14, dept_objs[4]),
        ('Olivia', 'Taylor', 'Cardiology', 'MD Cardiology', 6, dept_objs[0]),
        ('James', 'Anderson', 'Neurology', 'MD Neurology', 9, dept_objs[1]),
        ('Amanda', 'White', 'Orthopedics', 'MS Ortho, FRCS', 11, dept_objs[2]),
        ('Daniel', 'Harris', 'Pediatrics', 'MD Pediatrics', 7, dept_objs[3]),
        ('Jessica', 'Clark', 'General Medicine', 'MBBS, MD', 5, dept_objs[4]),
    ]

    doctor_objs = []
    for i, (fn, ln, spec, qual, exp, dept) in enumerate(doctor_names):
        uname = f"dr.{fn.lower()}"
        if uname == 'dr.robert':
            u = user_map[UserRole.DOCTOR]
        else:
            u = User.objects.create_user(
                username=uname,
                email=f"{uname}@medicare.com",
                password='Password123!',
                first_name=fn,
                last_name=ln,
                role=UserRole.DOCTOR
            )
        doc = Doctor.objects.create(
            user=u,
            doctor_id=f"DOC-2026-{101+i}",
            specialization=spec,
            qualification=qual,
            experience_years=exp,
            department=dept,
            consultation_fee=500.00 + (exp * 50),
            available_days=["Mon", "Tue", "Wed", "Thu", "Fri"],
            available_times="09:00 AM - 05:00 PM"
        )
        doctor_objs.append(doc)

    print("Creating Patients...")
    patients_data = [
        ('John Doe', '1990-05-15', 'Male', 'O+', '9876543210', 'john.doe@example.com'),
        ('Mary Jane', '1985-11-20', 'Female', 'A+', '9876543211', 'mary.jane@example.com'),
        ('Alex Turner', '1992-03-10', 'Male', 'B+', '9876543212', 'alex.turner@example.com'),
        ('Emma Watson', '1995-08-25', 'Female', 'AB+', '9876543213', 'emma.watson@example.com'),
        ('Chris Evans', '1982-06-13', 'Male', 'O-', '9876543214', 'chris.evans@example.com'),
        ('Scarlett Johansson', '1984-11-22', 'Female', 'A-', '9876543215', 'scarlett.j@example.com'),
        ('Bruce Wayne', '1980-02-19', 'Male', 'B-', '9876543216', 'bruce.w@example.com'),
        ('Diana Prince', '1988-04-30', 'Female', 'O+', '9876543217', 'diana.p@example.com'),
        ('Peter Parker', '2001-08-10', 'Male', 'AB-', '9876543218', 'peter.p@example.com'),
        ('Tony Stark', '1975-05-29', 'Male', 'O+', '9876543219', 'tony.s@example.com'),
    ]

    patient_objs = []
    for i, (name, dob, gender, blood, phone, email) in enumerate(patients_data):
        if name == 'John Doe':
            pu = user_map[UserRole.PATIENT]
        else:
            pu = User.objects.create_user(
                username=name.lower().replace(' ', '.'),
                email=email,
                password='Password123!',
                first_name=name.split()[0],
                last_name=name.split()[1],
                role=UserRole.PATIENT
            )
        p = Patient.objects.create(
            user=pu,
            patient_id=f"PAT-2026-00{i+1:02d}",
            full_name=name,
            dob=dob,
            age=2026 - int(dob.split('-')[0]),
            gender=gender,
            blood_group=blood,
            phone=phone,
            email=email,
            address="742 Evergreen Terrace, Sector 4",
            emergency_contact="Emergency Contact: +1 555-911-000",
            medical_history="Mild hypertension, Dust allergy" if i % 2 == 0 else "None",
            allergies="Penicillin" if i % 3 == 0 else "None"
        )
        patient_objs.append(p)

    print("Creating Staff...")
    staff_roles = [
        (user_map[UserRole.NURSE], UserRole.NURSE, dept_objs[0], 'BSN Nursing', 35000.00),
        (user_map[UserRole.RECEPTIONIST], UserRole.RECEPTIONIST, dept_objs[4], 'B.Com Management', 28000.00),
        (user_map[UserRole.PHARMACIST], UserRole.PHARMACIST, None, 'B.Pharm Pharmacy', 32000.00),
        (user_map[UserRole.LAB_STAFF], UserRole.LAB_STAFF, None, 'B.Sc Medical Lab Tech', 30000.00),
        (user_map[UserRole.ACCOUNTANT], UserRole.ACCOUNTANT, None, 'M.Com Finance', 40000.00),
    ]
    for i, (u, r, d, q, sal) in enumerate(staff_roles):
        Staff.objects.create(
            user=u,
            employee_id=f"EMP-2026-{100+i}",
            role=r,
            department=d,
            qualification=q,
            salary=sal
        )

    print("Creating Wards and Beds...")
    wards_info = [
        ('General Male Ward', 'GENERAL', 8),
        ('General Female Ward', 'GENERAL', 8),
        ('Intensive Care Unit (ICU)', 'ICU', 6),
        ('Emergency Observation', 'EMERGENCY', 6),
        ('Private Deluxe Wards', 'PRIVATE', 4),
    ]
    bed_objs = []
    for name, wtype, count in wards_info:
        w = Ward.objects.create(name=name, ward_type=wtype, total_beds=count)
        rate = 1000.00 if wtype == 'GENERAL' else (3500.00 if wtype == 'ICU' else 2500.00)
        for b_num in range(1, count + 1):
            st = 'AVAILABLE'
            if b_num in [1, 2] and wtype == 'GENERAL':
                st = 'OCCUPIED'
            elif b_num == 3 and wtype == 'ICU':
                st = 'RESERVED'
            bed = Bed.objects.create(
                ward=w,
                bed_number=f"{w.code if hasattr(w, 'code') else name[:3].upper()}-{b_num:02d}",
                status=st,
                daily_rate=rate
            )
            bed_objs.append(bed)

    print("Creating Admissions & Emergency Cases...")
    admit_p = patient_objs[0]
    admit_d = doctor_objs[0]
    occ_bed = [b for b in bed_objs if b.status == 'OCCUPIED'][0]
    adm = Admission.objects.create(
        admission_id="ADM-2026-0001",
        patient=admit_p,
        doctor=admit_d,
        bed=occ_bed,
        admission_reason="Acute Chest Discomfort and Palpitations",
        expected_discharge=timezone.now().date() + timedelta(days=3),
        status="ADMITTED"
    )

    EmergencyCase.objects.create(
        case_id="EMG-2026-001",
        patient_name="Michael Scott",
        age=45,
        gender="Male",
        contact="9876500000",
        priority="CRITICAL",
        assigned_doctor=doctor_objs[4],
        assigned_nurse=user_map[UserRole.NURSE],
        treatment_notes="Severe trauma following road accident. Stabilized with oxygen IV.",
        status="ACTIVE"
    )

    print("Creating Appointments & OPD Tokens...")
    time_slots = ["09:00 AM", "10:00 AM", "11:30 AM", "02:00 PM", "03:30 PM"]
    today = timezone.now().date()
    
    for i in range(8):
        p = patient_objs[i % len(patient_objs)]
        d = doctor_objs[i % len(doctor_objs)]
        slot = time_slots[i % len(time_slots)]
        status_choice = AppointmentStatus.CONFIRMED if i % 2 == 0 else AppointmentStatus.PENDING
        if i == 0:
            status_choice = AppointmentStatus.COMPLETED

        Appointment.objects.create(
            appointment_id=f"APT-2026-{1001+i}",
            patient=p,
            doctor=d,
            department=d.department,
            date=today + timedelta(days=(i % 3)),
            time_slot=slot,
            reason="Routine health checkup & blood pressure review",
            status=status_choice
        )

        OPDToken.objects.create(
            token_number=i+1,
            token_code=f"OPD-2026-{100+i}",
            patient=p,
            doctor=d,
            date=today,
            status='WAITING' if i > 0 else 'COMPLETED',
            consultation_fee=d.consultation_fee
        )

    print("Creating EMR & Prescriptions...")
    EMRRecord.objects.create(
        patient=patient_objs[0],
        doctor=doctor_objs[0],
        visit_date=today - timedelta(days=2),
        symptoms="Chest tightness, shortness of breath on exertion",
        diagnosis="Essential Mild Hypertension",
        vital_signs={"bp": "135/88 mmHg", "temp": "98.6 °F", "pulse": "78 bpm", "spo2": "98%"},
        treatment_plan="Low sodium diet, regular walking 30 mins daily, anti-hypertensive medication.",
        doctor_notes="Patient advised to maintain daily blood pressure log."
    )

    Prescription.objects.create(
        prescription_code="RX-2026-0001",
        patient=patient_objs[0],
        doctor=doctor_objs[0],
        diagnosis="Essential Mild Hypertension",
        items=[
            {"medicine_name": "Amlovas 5mg (Amlodipine)", "dosage": "5 mg", "frequency": "1 time/day", "duration": "30 days", "instructions": "Take in morning after breakfast"},
            {"medicine_name": "Ecoaspirin 75mg", "dosage": "75 mg", "frequency": "1 time/day", "duration": "30 days", "instructions": "Take after night dinner"}
        ],
        status="ACTIVE"
    )

    print("Creating Medicines & Inventory...")
    medicines = [
        ("MED-101", "Paracetamol 650mg", "Analgesic", "Cipla Ltd", "BATCH-2026-A", 150, 20, 30.00, today + timedelta(days=365)),
        ("MED-102", "Amlovas 5mg", "Cardiovascular", "Sun Pharma", "BATCH-2026-B", 80, 25, 45.00, today + timedelta(days=400)),
        ("MED-103", "Azithromycin 500mg", "Antibiotic", "Zydus Cadila", "BATCH-2026-C", 15, 30, 120.00, today + timedelta(days=180)), # Low stock alert!
        ("MED-104", "Metformin 500mg", "Antidiabetic", "Torrent Pharma", "BATCH-2026-D", 200, 40, 25.00, today + timedelta(days=500)),
        ("MED-105", "Pantoprazole 40mg", "Gastrointestinal", "Alkem Lab", "BATCH-2026-E", 10, 15, 60.00, today + timedelta(days=15)), # Low stock + near expiry!
    ]
    for code, name, cat, mfg, batch, qty, th, price, exp in medicines:
        Medicine.objects.create(
            medicine_code=code, name=name, category=cat, manufacturer=mfg,
            batch_number=batch, quantity=qty, min_threshold=th, price=price,
            expiry_date=exp, supplier="National Pharma Distributors"
        )

    inventory = [
        ("INV-001", "Disposable Syringes 5ml", "Consumable", 500, "pcs", 100, "MedTech Supplies", today - timedelta(days=30)),
        ("INV-002", "N95 Surgical Masks", "Protective", 80, "boxes", 20, "Safety First Co", today - timedelta(days=15)),
        ("INV-003", "Digital ECG Machine", "Equipment", 4, "units", 2, "Biomedical Systems", today - timedelta(days=100)),
        ("INV-004", "Sterile Latex Gloves (M)", "Consumable", 15, "boxes", 30, "MedTech Supplies", today - timedelta(days=10)), # Low stock!
    ]
    for code, name, cat, qty, unit, reorder, supp, pdate in inventory:
        InventoryItem.objects.create(
            item_code=code, name=name, category=cat, quantity=qty, unit=unit,
            reorder_level=reorder, supplier=supp, purchase_date=pdate
        )

    print("Creating Lab Tests & Reports...")
    labs = [
        ("LAB-CBC", "Complete Blood Count (CBC)", "Hematology", 450.00, "RBC: 4.5-5.9 M/uL, WBC: 4.5-11.0 K/uL"),
        ("LAB-BS", "Fasting Blood Sugar (FBS)", "Biochemistry", 250.00, "70 - 99 mg/dL"),
        ("LAB-LIPID", "Lipid Profile Test", "Biochemistry", 850.00, "Cholesterol < 200 mg/dL"),
        ("LAB-XRAY", "Chest X-Ray PA View", "Radiology", 600.00, "Normal Lung Fields & Cardiac Size"),
        ("LAB-ECG", "12-Lead Electrocardiogram", "Cardiology", 500.00, "Normal Sinus Rhythm"),
    ]
    lab_objs = []
    for code, name, cat, cost, nrange in labs:
        lt = LabTest.objects.create(code=code, name=name, category=cat, cost=cost, normal_range=nrange)
        lab_objs.append(lt)

    LabReport.objects.create(
        report_code="LRP-2026-001",
        patient=patient_objs[0],
        doctor=doctor_objs[0],
        lab_test=lab_objs[4], # ECG
        status="COMPLETED",
        results_summary="Normal sinus rhythm with rate 76 bpm. No ST-segment elevation.",
        sample_details="12-Lead ECG Tracing recorded at Bedside"
    )
    LabReport.objects.create(
        report_code="LRP-2026-002",
        patient=patient_objs[1],
        doctor=doctor_objs[1],
        lab_test=lab_objs[0], # CBC
        status="REQUESTED",
        sample_details="Venous blood sample pending collection"
    )

    print("Creating Nursing Vitals & Billing...")
    NursingVitals.objects.create(
        patient=patient_objs[0],
        nurse=user_map[UserRole.NURSE],
        temperature="98.4 °F",
        blood_pressure="128/82 mmHg",
        heart_rate="74 bpm",
        oxygen_saturation="99 %",
        respiratory_rate="16 bpm",
        notes="Patient comfortable, reports no pain."
    )

    b1 = Bill.objects.create(
        bill_code="INV-2026-001",
        patient=patient_objs[0],
        admission=adm,
        consultation_fee=600.00,
        room_charges=3000.00,
        lab_charges=500.00,
        pharmacy_charges=450.00,
        tax_amount=227.50,
        discount=200.00,
        total_amount=4577.50,
        paid_amount=3000.00,
        balance_amount=1577.50,
        status="PARTIALLY_PAID"
    )

    Payment.objects.create(
        payment_code="PAY-2026-001",
        bill=b1,
        amount=3000.00,
        payment_method="UPI",
        status="SUCCESS"
    )

    print("Creating System Notifications & Audit Logs...")
    Notification.objects.create(
        user=user_map[UserRole.PATIENT],
        title="Appointment Confirmed",
        message="Your appointment with Dr. Robert Smith is confirmed for today at 10:00 AM.",
        type="APPOINTMENT"
    )
    Notification.objects.create(
        user=user_map[UserRole.SUPER_ADMIN],
        title="Low Pharmacy Stock Alert",
        message="Azithromycin 500mg is running low (15 units remaining).",
        type="STOCK"
    )

    AuditLog.objects.create(
        user=user_map[UserRole.SUPER_ADMIN],
        user_role="SUPER_ADMIN",
        action="System Initialized with Demo Seed Data",
        module="System Administration",
        details="Full database populated with realistic demo records for engineering viva presentation."
    )

    print("Database seeding completed successfully!")

if __name__ == '__main__':
    run_seed()
