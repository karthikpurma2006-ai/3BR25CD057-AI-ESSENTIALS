# Sanjeevini Multispeciality Hospital Management System — Engineering Final-Year Viva & Project Documentation

## 1. Problem Statement
Manual paper-based hospital record management leads to fragmented patient records, scheduling conflicts, double-booked doctors, unmonitored bed availability, delayed laboratory reports, inventory stock-outs, and billing calculation errors.

## 2. Objectives
- Provide a unified, digital web-based platform to manage hospital operations across 9 distinct user roles.
- Eliminate appointment double-booking using server-side validation.
- Automate inpatient bed status tracking (`Available`, `Occupied`, `Reserved`, `Maintenance`) with auto-release on discharge.
- Streamline electronic medical records (EMR), digital prescriptions, pharmacy inventory alerts, and diagnostic lab workflows.
- Provide automated billing calculation with PDF invoice and prescription export.

## 3. Existing System vs. Proposed System
| Parameter | Existing Manual System | Proposed Sanjeevini HMS System |
| :--- | :--- | :--- |
| **Data Storage** | Paper registers, scattered files | Centralized Relational SQLite/PostgreSQL Database |
| **Appointments** | Manual logging, prone to double booking | Real-time time slot selector with validation |
| **Bed Management** | Physical inspection of wards | Interactive visual bed occupancy grid |
| **Prescriptions** | Hand-written prescriptions | Digital prescription builder & PDF export |
| **Billing** | Manual calculation, error-prone | Automated itemized calculation (tax + discount) |
| **Security** | Unrestricted physical file access | Role-Based Access Control (RBAC) & Audit Logs |

## 4. Functional Requirements
1. **User Authentication & Role Management**: Token-based auth for 9 roles.
2. **Patient & EMR Management**: Auto ID generation (`PAT-2026-XXXX`), medical history, symptoms, diagnosis.
3. **Appointment & OPD Engine**: Time slot calendar, double-booking prevention, live OPD token queue.
4. **Inpatient Ward & Bed Management**: Ward beds status, admission, discharge summary generation with automatic bed release.
5. **Pharmacy & Inventory**: Stock management, min-threshold alerts, expiry date tracking.
6. **Laboratory Diagnostics**: Test ordering, status progression (`Requested` → `Sample Collected` → `Processing` → `Completed`), report output.
7. **Billing & Payments**: Itemized billing calculator, payment recording (Cash, Card, UPI, Online), invoice PDF generation.
8. **Audit Trail**: Real-time activity logging with user role, timestamp, and IP tracking.

## 5. Non-Functional Requirements
- **Performance**: Sub-100ms API response times.
- **Usability**: Responsive glassmorphic medical theme accessible across desktop, tablet, and mobile browsers.
- **Reliability & Security**: Password hashing (`PBKDF2_SHA256`), CSRF protection, Token authorization headers.

## 6. System Architecture
```mermaid
graph TD
    Client[React Frontend - Vite / Lucide Icons]
    REST[REST API Layer - Axios / Fetch]
    Django[Django REST Framework Backend]
    Auth[Token Authentication & RBAC Middleware]
    Models[Django ORM Relational Models]
    DB[(SQLite Database / PostgreSQL Ready)]

    Client -->|HTTP Requests / JSON| REST
    REST --> Auth
    Auth --> Django
    Django --> Models
    Models --> DB
```

## 7. Entity Relationship (ER) Schema
```mermaid
erDiagram
    USER ||--o| DOCTOR : "has profile"
    USER ||--o| PATIENT : "has profile"
    USER ||--o| STAFF : "has profile"
    DEPARTMENT ||--o{ DOCTOR : "contains"
    PATIENT ||--o{ APPOINTMENT : "books"
    DOCTOR ||--o{ APPOINTMENT : "conducts"
    PATIENT ||--o{ ADMISSION : "undergoes"
    BED ||--o| ADMISSION : "assigned to"
    WARD ||--o{ BED : "houses"
    PATIENT ||--o{ EMR_RECORD : "owns"
    DOCTOR ||--o{ PRESCRIPTION : "issues"
    PATIENT ||--o{ PRESCRIPTION : "receives"
    PATIENT ||--o{ LAB_REPORT : "undergoes"
    LAB_TEST ||--o{ LAB_REPORT : "defines"
    PATIENT ||--o{ BILL : "billed for"
    BILL ||--o{ PAYMENT : "settled by"
```

## 8. Data Flow Diagram (DFD Level 1)
```mermaid
graph LR
    Patient((Patient)) -->|1. Book Appt / Register| ApptProcess[Appointment & OPD Engine]
    Doctor((Doctor)) -->|2. Examine & Diagnose| EMRProcess[EMR & Prescription Engine]
    Nurse((Nurse)) -->|3. Record Vitals / Ward| WardProcess[Ward & Bed Engine]
    Pharm((Pharmacist)) -->|4. Dispense Medicine| PharmProcess[Pharmacy Inventory Engine]
    Lab((Lab Staff)) -->|5. Upload Results| LabProcess[Lab Diagnostics Engine]
    Accountant((Accountant)) -->|6. Record Payment| BillingProcess[Billing & Invoice Engine]

    ApptProcess --> DB[(Relational Database)]
    EMRProcess --> DB
    WardProcess --> DB
    PharmProcess --> DB
    LabProcess --> DB
    BillingProcess --> DB
```

## 9. Testing & Verification Summary
1. **Double-Booking Validation**: Verified that attempting to book Dr. Robert Smith at 10:00 AM on 2026-09-03 for a second patient returns a `400 Bad Request` double-booking validation error.
2. **Bed Occupancy Lifecycle**: Verified that admitting a patient to BED-101 marks its status as `OCCUPIED`, and executing the discharge action returns its status to `AVAILABLE`.
3. **Prescription PDF Generation**: Verified client-side canvas rendering and PDF export of digital prescriptions.
4. **Billing Calculation**: Verified calculation formula `Total = (Consultation + Room + Lab + Pharmacy + Procedure + Tax) - Discount`.

## 10. Future Scope
- Integration with third-party payment gateways (Razorpay / Stripe) for online patient payment processing.
- SMS and WhatsApp automated notification dispatch for appointment reminders and lab result readiness.
- Telemedicine video consultation integration via WebRTC.
