# Sanjeevini Multispeciality Hospital Management System (HMS)

> **Academic & Engineering Final-Year Project Presentation**
> A complete, modern, responsive, and fully functional healthcare operations system featuring React, Django REST Framework, 9 role-based access control dashboards, relational database, real-time double-booking protection, bed status grid, PDF prescription/invoice generator, and audit logging.

---

## 🌟 Key Highlights & Features

1. **Role-Based Access Control (RBAC)** across 9 specialized user roles:
   - **Super Admin** & **Hospital Admin**: System-wide analytics, department management, revenue charts, staff controls.
   - **Doctor**: Appointment queue, clinical diagnosis, electronic medical records (EMR), digital prescription builder.
   - **Nurse**: Ward bed monitoring visualizer, nursing vitals recorder, emergency triage response.
   - **Receptionist**: Patient self/manual registration, OPD token generator, consultation check-in.
   - **Pharmacist**: Medicine stock tracker, low-stock & expiry alerts, prescription queue dispenser.
   - **Lab Technician**: Diagnostic test catalog, sample status workflow (`Requested` → `Sample Collected` → `Processing` → `Completed`), report uploader.
   - **Accountant**: Financial revenue collection, itemized billing generator, balance due calculator.
   - **Patient**: Personal Health Portal, upcoming appointment calendar, PDF prescription downloads, billing statements.

2. **Core Operational Modules**:
   - **Public Landing Page**: Professional homepage with doctor search, department highlights, and 24/7 emergency hotlines.
   - **Appointment & OPD Engine**: Double-booking prevention algorithm (prevents scheduling the same doctor at the same date and time slot).
   - **Interactive Bed Grid**: Real-time visual bed occupancy grid (`Available`, `Occupied`, `Reserved`, `Maintenance`) across General Wards, ICU, Emergency, and Private rooms.
   - **Discharge Automation**: Generates discharge summary, updates patient status, and automatically releases the assigned bed back to `Available`.
   - **Exportable PDF Reports & Invoices**: Client-side PDF generation for prescriptions and billing invoices using `html2pdf.js`, and CSV data exports.
   - **Audit Logs & Security**: Comprehensive audit logging for all critical system actions with IP tracking and timestamps.

---

## 🔑 Demo User Credentials (Password for ALL: `Password123!`)

For quick presentation and evaluation, 1-Click login buttons are available on the login modal:

| Role | Username / Email | Password | Primary Capabilities |
| :--- | :--- | :--- | :--- |
| **Super Admin** | `admin` / `admin@medicare.com` | `Password123!` | Full system control, analytics, audit logs |
| **Hospital Admin** | `hospadmin` / `hospadmin@medicare.com` | `Password123!` | Staff, departments, hospital setup |
| **Doctor** | `dr.smith` / `dr.smith@medicare.com` | `Password123!` | Appointments, EMR, prescription builder |
| **Nurse** | `nurse.sarah` / `nurse.sarah@medicare.com` | `Password123!` | Ward beds, vitals recording |
| **Receptionist** | `receptionist` / `receptionist@medicare.com` | `Password123!` | Patient registration, OPD tokens |
| **Pharmacist** | `pharmacist` / `pharmacist@medicare.com` | `Password123!` | Drug inventory, low-stock alerts |
| **Lab Staff** | `labtech` / `labtech@medicare.com` | `Password123!` | Diagnostic lab test results |
| **Accountant** | `accountant` / `accountant@medicare.com` | `Password123!` | Invoice billing, payment collection |
| **Patient** | `patient.john` / `patient.john@medicare.com` | `Password123!` | Patient portal, PDF downloads |

---

## 🛠️ Technology Stack

- **Frontend**: React (Vite), Glassmorphic Custom Medical CSS, Lucide Icons, Chart.js, `html2pdf.js`.
- **Backend**: Python 3.10+, Django 5.0+, Django REST Framework (DRF), `django-cors-headers`.
- **Database**: SQLite (Zero-config out-of-the-box, relational ERD design).

---

## 🚀 How to Run Locally

### 1. Backend Server Setup
```bash
# Navigate to backend directory
cd backend

# Activate Virtual Environment (Windows PowerShell)
..\venv\Scripts\Activate.ps1

# Run database migrations and seed script (if not already seeded)
python manage.py migrate
python seed_data.py

# Start Django REST Server on Port 8000
python manage.py runserver 0.0.0.0:8000
```
Backend API will be accessible at: `http://localhost:8000/api/`

### 2. Frontend Application Setup
```bash
# Navigate to frontend directory
cd frontend

# Install Node dependencies (if needed)
npm install

# Start Vite React Dev Server
npm run dev
```
Frontend Web App will be accessible at: `http://localhost:5173/`

---

## 📚 Project Viva Documentation
Detailed engineering viva documentation including Problem Statement, System Architecture, Use-Case Diagrams, Data Flow Diagrams (DFDs), ER Diagram, and Database Schema is available in [engineering_project_docs.md](file:///c:/Users/Ganesh%20P/Downloads/hospital%20management%20system/engineering_project_docs.md).
